package com.example

import com.example.data.DutyRulesEngine
import com.example.data.ReportCategory
import com.example.model.CreditType
import com.example.model.DiaryEntry
import com.example.model.EntryType
import com.example.model.LeaveCredit
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class DutyRulesEngineTest {

    @Test
    fun phCredit_validWithinThreeMonths_andInvalidOnHolidayOrWeeklyOffOrBeforeDate() {
        // 2026-08-15 is Independence Day (Saturday). Suppose Weekly Off = Sunday (7).
        val ph = LeaveCredit(
            id = "ph_2026-08-15",
            creditType = CreditType.PH.name,
            sourceDate = "2026-08-15",
            expiresAtDate = "2026-11-15"
        )
        // Before PH date -> invalid
        assertFalse(DutyRulesEngine.isPhCreditValidForDate(ph, LocalDate.of(2026, 8, 14), 7))
        // On another Public Holiday (2026-09-14 Ganesh Chaturthi) -> invalid
        assertFalse(DutyRulesEngine.isPhCreditValidForDate(ph, LocalDate.of(2026, 9, 14), 7))
        // On Weekly Off (Sunday 2026-08-16) -> invalid
        assertFalse(DutyRulesEngine.isPhCreditValidForDate(ph, LocalDate.of(2026, 8, 16), 7))
        // On regular weekday within 3 months -> valid
        assertTrue(DutyRulesEngine.isPhCreditValidForDate(ph, LocalDate.of(2026, 8, 17), 7))
        assertTrue(DutyRulesEngine.isPhCreditValidForDate(ph, LocalDate.of(2026, 11, 13), 7))
        // After 3 months (2026-11-16) -> expired / invalid
        assertFalse(DutyRulesEngine.isPhCreditValidForDate(ph, LocalDate.of(2026, 11, 16), 7))
        assertTrue(DutyRulesEngine.isPhExpired(ph, LocalDate.of(2026, 11, 16)))
    }

    @Test
    fun cOffCredit_onlyValidStrictlyAfterWorkedWeeklyOff_andNotOnHolidayOrWeeklyOff() {
        val cOff = LeaveCredit(
            id = "coff_2026-11-15",
            creditType = CreditType.C_OFF.name,
            sourceDate = "2026-11-15"
        )
        // Before or same day -> invalid
        assertFalse(DutyRulesEngine.isCOffCreditValidForDate(cOff, LocalDate.of(2026, 11, 14), 7))
        assertFalse(DutyRulesEngine.isCOffCreditValidForDate(cOff, LocalDate.of(2026, 11, 15), 7))
        // Next Sunday (Weekly Off) -> invalid
        assertFalse(DutyRulesEngine.isCOffCreditValidForDate(cOff, LocalDate.of(2026, 11, 22), 7))
        // Public holiday (2026-11-24 Guru Nanak Jayanti) -> invalid
        assertFalse(DutyRulesEngine.isCOffCreditValidForDate(cOff, LocalDate.of(2026, 11, 24), 7))
        // Valid weekday after -> valid
        assertTrue(DutyRulesEngine.isCOffCreditValidForDate(cOff, LocalDate.of(2026, 11, 16), 7))
    }

    @Test
    fun weeklyOffBreak_leaveBeforeAndAfterWeeklyOff_countsAsBrokenLeave() {
        // 2026-11-15 is Sunday (weeklyOffDay = 7)
        val entries = listOf(
            DiaryEntry(dateIso = "2026-11-14", entryType = EntryType.LEAVE.name, leaveType = "CL"),
            DiaryEntry(dateIso = "2026-11-16", entryType = EntryType.LEAVE.name, leaveType = "LWP")
        ).associateBy { it.dateIso }

        assertTrue(DutyRulesEngine.isWeeklyOffBroken(LocalDate.of(2026, 11, 15), 7, entries))
    }

    @Test
    fun reportRows_neverIncludeFutureDates() {
        val today = LocalDate.of(2026, 11, 23)
        val entries = listOf(
            DiaryEntry(dateIso = "2026-11-22", entryType = EntryType.DUTY.name, dutyNumber = "101"),
            DiaryEntry(dateIso = "2026-11-23", entryType = EntryType.DUTY.name, dutyNumber = "102"),
            DiaryEntry(dateIso = "2026-11-25", entryType = EntryType.DUTY.name, dutyNumber = "999")
        )
        val rows = DutyRulesEngine.buildReportRows(
            startDate = LocalDate.of(2026, 11, 1),
            endDate = LocalDate.of(2026, 11, 30),
            today = today,
            weeklyOffDay = 7,
            entries = entries
        )
        assertTrue(rows.none { it.date.isAfter(today) })
        assertEquals(2, rows.count { it.category == ReportCategory.DUTY })
    }
}
