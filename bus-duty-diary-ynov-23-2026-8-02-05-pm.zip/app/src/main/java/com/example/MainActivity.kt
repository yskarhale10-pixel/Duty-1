package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.authStateFlow
import com.example.auth.signOut
import com.example.data.DiaryRepository
import com.example.data.FirestoreProvider
import com.example.data.PreferencesManager
import com.example.localization.stringsFor
import com.example.model.UiState
import com.example.model.UserPreferencesState
import com.example.ui.components.HeaderClockBar
import com.example.ui.components.HorizontalMenuBar
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.DutyReportScreen
import com.example.ui.screens.LeaveScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.BusDutyDiaryTheme
import com.example.util.AppShareHelper
import com.example.viewmodel.DiaryViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppRoot()
        }
    }
}

@Composable
fun AppRoot() {
    val context = LocalContext.current
    val preferencesManager = remember(context) { PreferencesManager(context.applicationContext) }
    val preferences by preferencesManager.preferencesFlow.collectAsStateWithLifecycle(
        initialValue = UserPreferencesState()
    )
    val strings = remember(preferences.language) { stringsFor(preferences.language) }

    val auth: FirebaseAuth = Firebase.auth
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)

    BusDutyDiaryTheme(
        themeStyle = preferences.themeStyle,
        darkTheme = preferences.darkMode,
        fontChoice = preferences.fontChoice,
        fontScale = preferences.fontSizeScale
    ) {
        val user = currentUser
        if (user == null || !preferences.pinVerifiedForSession) {
            AuthScreen(
                strings = strings,
                preferences = preferences,
                preferencesManager = preferencesManager,
                onAuthenticatedAndUnlocked = { _ -> }
            )
        } else {
            val uid = user.uid
            key(uid) {
                AuthenticatedDiaryShell(
                    currentUserId = uid,
                    preferences = preferences,
                    preferencesManager = preferencesManager
                )
            }
        }
    }
}

@Composable
private fun AuthenticatedDiaryShell(
    currentUserId: String,
    preferences: UserPreferencesState,
    preferencesManager: PreferencesManager
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val strings = remember(preferences.language) { stringsFor(preferences.language) }

    val viewModel: DiaryViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) { "APPLICATION_KEY missing" }
                val db = FirestoreProvider.getDatabase(app)
                DiaryViewModel(
                    repository = DiaryRepository(db),
                    preferencesManager = PreferencesManager(app),
                    currentUserId = currentUserId
                )
            }
        }
    )

    val profileState by viewModel.profileState.collectAsStateWithLifecycle()
    val entriesState by viewModel.entriesState.collectAsStateWithLifecycle()
    val creditsState by viewModel.creditsState.collectAsStateWithLifecycle()
    val isSaving by viewModel.isSaving.collectAsStateWithLifecycle()
    val isSyncing by viewModel.isSyncing.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(viewModel) {
        viewModel.snackbarMessage.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val pagerState = rememberPagerState(initialPage = 0, pageCount = { 5 })

    BackHandler(enabled = pagerState.currentPage != 0) {
        scope.launch { pagerState.animateScrollToPage(0) }
    }

    fun performLogout() {
        scope.launch {
            preferencesManager.setPinVerified(false)
            signOut(credentialManager = credentialManager, scope = scope)
        }
    }

    val profile = (profileState as? UiState.Success)?.data
    val entries = (entriesState as? UiState.Success)?.data.orEmpty()
    val credits = (creditsState as? UiState.Success)?.data.orEmpty()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            HeaderClockBar(
                strings = strings,
                language = preferences.language,
                showHomeShare = true,
                onShareAppClick = { AppShareHelper.shareInstalledApk(context) }
            )

            HorizontalMenuBar(
                strings = strings,
                selectedIndex = pagerState.currentPage,
                onSelectTab = { index ->
                    scope.launch { pagerState.animateScrollToPage(index) }
                }
            )

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) { page ->
                when {
                    profileState is UiState.Loading || entriesState is UiState.Loading -> {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    }
                    profileState is UiState.Error -> {
                        Surface(modifier = Modifier.padding(16.dp)) {
                            Text((profileState as UiState.Error).message)
                        }
                    }
                    else -> {
                        when (page) {
                            0 -> ProfileScreen(
                                strings = strings,
                                language = preferences.language,
                                currentUserId = currentUserId,
                                profile = profile,
                                isSaving = isSaving,
                                onSaveProfile = { updated, exists ->
                                    viewModel.saveProfile(
                                        profile = updated.copy(
                                            email = updated.email.ifBlank { Firebase.auth.currentUser?.email ?: "" }
                                        ),
                                        existingExists = exists,
                                        successMsg = strings.profileSubmittedBadge
                                    )
                                },
                                onLogoutClicked = { performLogout() }
                            )
                            1 -> CalendarScreen(
                                strings = strings,
                                language = preferences.language,
                                currentUserId = currentUserId,
                                profile = profile,
                                entries = entries,
                                credits = credits,
                                onSaveEntry = { newEntry, oldEntry ->
                                    viewModel.saveDiaryEntry(
                                        entry = newEntry,
                                        existingEntry = oldEntry,
                                        weeklyOffDay = profile?.weeklyOffDay ?: 0,
                                        existingCredits = credits,
                                        successMsg = "${strings.saveEntryBtn}: ${newEntry.dateIso}"
                                    )
                                },
                                onDeleteEntry = { oldEntry ->
                                    viewModel.deleteDiaryEntry(
                                        entry = oldEntry,
                                        successMsg = "${strings.deleteEntryBtn}: ${oldEntry.dateIso}"
                                    )
                                },
                                onDepositPhCredit = { dateIso, title ->
                                    viewModel.depositPhCredit(
                                        dateIso = dateIso,
                                        title = title,
                                        successMsg = "${strings.depositPhBtn}: $dateIso"
                                    )
                                }
                            )
                            2 -> DutyReportScreen(
                                strings = strings,
                                language = preferences.language,
                                profile = profile,
                                entries = entries
                            )
                            3 -> LeaveScreen(
                                strings = strings,
                                language = preferences.language,
                                profile = profile,
                                entries = entries,
                                credits = credits
                            )
                            4 -> SettingsScreen(
                                strings = strings,
                                preferences = preferences,
                                preferencesManager = preferencesManager,
                                isSyncing = isSyncing,
                                onSyncClick = {
                                    viewModel.syncNow(
                                        successMsg = "${strings.syncDataBtn} ✓",
                                        offlineMsg = strings.offlineLabel
                                    )
                                },
                                onLogFeedback = { msg, channel ->
                                    viewModel.logFeedback(msg, channel)
                                },
                                onLogoutClick = { performLogout() }
                            )
                        }
                    }
                }
            }
        }
    }
}
