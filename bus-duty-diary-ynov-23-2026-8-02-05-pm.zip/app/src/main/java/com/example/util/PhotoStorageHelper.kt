package com.example.util

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

object PhotoStorageHelper {
    fun persistPickedPhotoLocally(context: Context, sourceUri: Uri, userId: String): String? {
        return try {
            val dir = File(context.filesDir, "profile_photos").apply { mkdirs() }
            val dest = File(dir, "avatar_$userId.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(dest).use { output ->
                    input.copyTo(output)
                }
            }
            dest.absolutePath
        } catch (_: Exception) {
            null
        }
    }
}
