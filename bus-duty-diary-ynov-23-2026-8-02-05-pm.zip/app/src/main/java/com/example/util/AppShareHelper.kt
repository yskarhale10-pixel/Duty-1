package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object AppShareHelper {

    fun copyInstalledApkToUri(context: Context, destinationUri: Uri): Boolean {
        return try {
            val sourcePath = context.applicationInfo.sourceDir
            val sourceFile = File(sourcePath)
            context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                FileInputStream(sourceFile).use { input ->
                    input.copyTo(out)
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun shareInstalledApk(context: Context) {
        try {
            val sourceFile = File(context.applicationInfo.sourceDir)
            val cacheDir = File(context.cacheDir, "apk").apply { mkdirs() }
            val outApk = File(cacheDir, "BusDutyDiary.apk")
            FileInputStream(sourceFile).use { input ->
                FileOutputStream(outApk).use { output ->
                    input.copyTo(output)
                }
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", outApk)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Bus Duty Diary App (APK)")
                putExtra(
                    Intent.EXTRA_TEXT,
                    "Bus Duty Diary (कर्मचारी ड्यूटी नोंद डायरी) Android APK - Created by Yadav Karhale"
                )
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Bus Duty Diary APK"))
        } catch (_: Exception) {
            shareAppInvite(context)
        }
    }

    fun shareAppInvite(context: Context) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Bus Duty Diary App")
            putExtra(
                Intent.EXTRA_TEXT,
                "Bus Duty Diary (कर्मचारी ड्यूटी नोंद डायरी) - चालक व वाहकांसाठी ऑफलाईन व ऑनलाईन ड्यूटी डायरी अँप.\nसंपर्क: Yadav Karhale (8208748351)"
            )
        }
        context.startActivity(Intent.createChooser(intent, "Share Bus Duty Diary"))
    }

    fun openWhatsApp(context: Context, phoneWithCountry: String = "918208748351", prefill: String = "") {
        val encoded = Uri.encode(prefill)
        val uri = Uri.parse("https://wa.me/$phoneWithCountry?text=$encoded")
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
    }

    fun openEmail(context: Context, email: String = "yskarhale10@gmail.com", subject: String = "Bus Duty Diary Support") {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$email")
            putExtra(Intent.EXTRA_SUBJECT, subject)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            val fallback = Intent(Intent.ACTION_SEND).apply {
                type = "message/rfc822"
                putExtra(Intent.EXTRA_EMAIL, arrayOf(email))
                putExtra(Intent.EXTRA_SUBJECT, subject)
            }
            context.startActivity(Intent.createChooser(fallback, "Send Email"))
        }
    }

    fun sendSms(context: Context, phone: String = "8208748351", body: String) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:$phone")
            putExtra("sms_body", body)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            shareAppInvite(context)
        }
    }
}
