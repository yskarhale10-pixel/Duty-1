package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.example.data.ReportCategory
import com.example.data.ReportRow
import com.example.model.EmployeeProfile
import java.io.File
import java.io.FileOutputStream

object PdfReportGenerator {

    fun generateDutyReportPdf(
        context: Context,
        periodTitle: String,
        profile: EmployeeProfile?,
        rows: List<ReportRow>,
        summaryLine: String
    ): Uri {
        val dir = File(context.cacheDir, "reports").apply { mkdirs() }
        val file = File(dir, "bus_duty_report_${System.currentTimeMillis()}.pdf")

        val pageWidth = 595 // A4 width in points (72 dpi)
        val pageHeight = 842
        val margin = 36f
        val contentWidth = (pageWidth - margin * 2).toInt()

        val document = PdfDocument()
        var pageNum = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create()
        var page = document.startPage(pageInfo)
        var canvas = page.canvas

        val headerBgPaint = Paint().apply { color = Color.parseColor("#B71C1C") }
        val titlePaint = TextPaint().apply {
            color = Color.WHITE
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val subtitlePaint = TextPaint().apply {
            color = Color.parseColor("#FFE0B2")
            textSize = 11f
            isAntiAlias = true
        }
        val bodyBoldPaint = TextPaint().apply {
            color = Color.parseColor("#1F1A1A")
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val bodyPaint = TextPaint().apply {
            color = Color.parseColor("#333333")
            textSize = 10f
            isAntiAlias = true
        }
        val dividerPaint = Paint().apply {
            color = Color.parseColor("#E0D6D3")
            strokeWidth = 1f
        }

        fun drawHeader(c: Canvas): Float {
            c.drawRect(0f, 0f, pageWidth.toFloat(), 86f, headerBgPaint)
            c.drawText("कर्मचारी ड्यूटी नोंद डायरी — Duty Report", margin, 34f, titlePaint)
            c.drawText(periodTitle, margin, 56f, subtitlePaint)
            val empLine = "Name: ${profile?.name ?: "-"}  |  Role: ${profile?.designation ?: "-"}  |  Mob: ${profile?.mobile ?: "-"}"
            c.drawText(empLine, margin, 74f, subtitlePaint)
            return 104f
        }

        var y = drawHeader(canvas)

        // Summary box
        val summaryLayout = StaticLayout.Builder
            .obtain(summaryLine, 0, summaryLine.length, bodyBoldPaint, contentWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .build()
        canvas.save()
        canvas.translate(margin, y)
        summaryLayout.draw(canvas)
        canvas.restore()
        y += summaryLayout.height + 12f
        canvas.drawLine(margin, y, pageWidth - margin, y, dividerPaint)
        y += 14f

        for (row in rows) {
            val badgePaint = Paint().apply {
                color = when (row.category) {
                    ReportCategory.DUTY -> Color.parseColor("#0F6B36")
                    ReportCategory.LEAVE -> Color.parseColor("#B71C1C")
                    ReportCategory.WEEKLY_OFF -> Color.parseColor("#1D4ED8")
                    ReportCategory.BROKEN_WEEKLY_OFF -> Color.parseColor("#C2410C")
                    ReportCategory.PH_TAKEN -> Color.parseColor("#0F766E")
                    ReportCategory.C_OFF_TAKEN -> Color.parseColor("#6D28D9")
                }
            }
            val textBlock = "${row.dateIso}  •  ${row.title}\n${row.subtitle}"
            val layout = StaticLayout.Builder
                .obtain(textBlock, 0, textBlock.length, bodyPaint, contentWidth - 18)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .build()

            if (y + layout.height + 24f > pageHeight - 40f) {
                document.finishPage(page)
                pageNum += 1
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create()
                page = document.startPage(pageInfo)
                canvas = page.canvas
                y = drawHeader(canvas)
            }

            canvas.drawCircle(margin + 5f, y + 8f, 4f, badgePaint)
            canvas.save()
            canvas.translate(margin + 16f, y)
            layout.draw(canvas)
            canvas.restore()

            y += layout.height + 10f
            canvas.drawLine(margin, y, pageWidth - margin, y, dividerPaint)
            y += 10f
        }

        document.finishPage(page)
        FileOutputStream(file).use { out -> document.writeTo(out) }
        document.close()

        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    fun sharePdf(context: Context, pdfUri: Uri, targetPackage: String? = null, emailRecipient: String? = null) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, pdfUri)
            putExtra(Intent.EXTRA_SUBJECT, "Bus Duty Diary Report (PDF)")
            putExtra(Intent.EXTRA_TEXT, "Bus Duty Diary - कर्मचारी ड्यूटी नोंद डायरी रिपोर्ट")
            if (!emailRecipient.isNullOrBlank()) {
                putExtra(Intent.EXTRA_EMAIL, arrayOf(emailRecipient))
            }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (!targetPackage.isNullOrBlank()) {
                setPackage(targetPackage)
            }
        }
        try {
            context.startActivity(Intent.createChooser(intent, "Share Duty Report PDF"))
        } catch (_: Exception) {
            val fallback = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, pdfUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(fallback, "Share Duty Report PDF"))
        }
    }
}
