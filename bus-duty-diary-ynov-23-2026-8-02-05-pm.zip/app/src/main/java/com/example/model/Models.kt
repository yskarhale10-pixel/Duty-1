package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class AppLanguage(val code: String, val nativeLabel: String) {
    MARATHI("mr", "मराठी"),
    HINDI("hi", "हिंदी"),
    ENGLISH("en", "English");

    companion object {
        fun fromCode(code: String?): AppLanguage =
            entries.firstOrNull { it.code == code } ?: MARATHI
    }
}

enum class AppThemeStyle(val labelMr: String, val labelHi: String, val labelEn: String) {
    CRIMSON_GOLD("लाल-सोनेरी (ST)", "लाल-सुनहरा (ST)", "Crimson & Gold"),
    SAHYADRI_EMERALD("सह्याद्री हिरवा", "सह्याद्री हरा", "Sahyadri Emerald"),
    KONKAN_OCEAN("कोकण निळा", "कोंकण नीला", "Konkan Ocean"),
    ROYAL_SAFFRON("भगवा-जांभळा", "भगवा-बैंगनी", "Royal Saffron");

    companion object {
        fun fromName(raw: String?): AppThemeStyle =
            entries.firstOrNull { it.name == raw } ?: CRIMSON_GOLD
    }
}

enum class AppFontChoice(val label: String) {
    NOTO_DEVANAGARI("Noto Sans Devanagari"),
    POPPINS("Poppins Modern"),
    TIRO_MARATHI("Tiro Marathi Classic"),
    SYSTEM_DEFAULT("System Default");

    companion object {
        fun fromName(raw: String?): AppFontChoice =
            entries.firstOrNull { it.name == raw } ?: NOTO_DEVANAGARI
    }
}

enum class FontSizeScale(val multiplier: Float, val labelMr: String, val labelHi: String, val labelEn: String) {
    SMALL(0.88f, "लहान", "छोटा", "Small"),
    MEDIUM(1.00f, "मध्यम", "मध्यम", "Medium"),
    LARGE(1.14f, "मोठा", "बड़ा", "Large"),
    EXTRA_LARGE(1.28f, "खूप मोठा", "बहुत बड़ा", "Extra Large");

    companion object {
        fun fromName(raw: String?): FontSizeScale =
            entries.firstOrNull { it.name == raw } ?: MEDIUM
    }
}

enum class Designation(val labelMr: String, val labelHi: String, val labelEn: String) {
    DRIVER("चालक", "चालक", "Driver"),
    CONDUCTOR("वाहक", "परिचालक", "Conductor"),
    DRIVER_CUM_CONDUCTOR("चालक cum वाहक", "चालक सह परिचालक", "Driver cum Conductor");

    companion object {
        fun fromName(raw: String?): Designation =
            entries.firstOrNull { it.name == raw } ?: DRIVER
    }
}

enum class DutyRole(val labelMr: String, val labelHi: String, val labelEn: String) {
    DRIVER("चालक", "चालक", "Driver"),
    CONDUCTOR("वाहक", "परिचालक", "Conductor");

    companion object {
        fun fromNameOrNull(raw: String?): DutyRole? =
            entries.firstOrNull { it.name == raw }
    }
}

enum class EntryType(val labelMr: String, val labelHi: String, val labelEn: String) {
    DUTY("ड्यूटी", "ड्यूटी", "Duty"),
    LEAVE("रजा", "अवकाश", "Leave"),
    PH("PH सुट्टी", "PH अवकाश", "PH"),
    C_OFF("C-Off सुट्टी", "C-Off अवकाश", "C-Off");

    companion object {
        fun fromName(raw: String?): EntryType =
            entries.firstOrNull { it.name == raw } ?: DUTY
    }
}

enum class LeaveType(val code: String, val labelMr: String, val labelHi: String, val labelEn: String) {
    CL("CL", "किरकोळ रजा (CL)", "आकस्मिक अवकाश (CL)", "Casual Leave (CL)"),
    EL("EL", "अर्जित रजा (EL)", "अर्जित अवकाश (EL)", "Earned Leave (EL)"),
    SL("SL", "वैद्यकीय रजा (SL)", "चिकित्सा अवकाश (SL)", "Sick / Medical Leave (SL)"),
    LWP("LWP", "दांडी / बिनपगारी (LWP)", "बिना वेतन / अनुपस्थित (LWP)", "Absent / Leave Without Pay (LWP)"),
    SPECIAL("SPECIAL", "विशेष रजा", "विशेष अवकाश", "Special Leave");

    companion object {
        fun fromNameOrNull(raw: String?): LeaveType? =
            entries.firstOrNull { it.name == raw }
    }
}

enum class CreditType {
    PH,
    C_OFF;

    companion object {
        fun fromName(raw: String?): CreditType =
            entries.firstOrNull { it.name == raw } ?: PH
    }
}

enum class CreditSourceKind {
    DEPOSITED,
    EARNED_DUTY;

    companion object {
        fun fromName(raw: String?): CreditSourceKind =
            entries.firstOrNull { it.name == raw } ?: DEPOSITED
    }
}

@Keep
@IgnoreExtraProperties
data class EmployeeProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val email: String = "",
    val mobile: String = "",
    val dateOfBirth: String = "",
    val designation: String = Designation.DRIVER.name,
    val weeklyOffDay: Int = 0, // 1=Mon .. 7=Sun, 0=Unset
    val photoUri: String = "",
    val profileSubmitted: Boolean = false,
    val pinHash: String = "",
    val pinSalt: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun designationEnum(): Designation = Designation.fromName(designation)

    fun isComplete(): Boolean =
        name.isNotBlank() &&
            dateOfBirth.isNotBlank() &&
            designation.isNotBlank() &&
            weeklyOffDay in 1..7 &&
            mobile.filter { it.isDigit() }.length >= 10
}

@Keep
@IgnoreExtraProperties
data class DiaryEntry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val dateIso: String = "",
    val entryType: String = EntryType.DUTY.name,
    val dutyNumber: String = "",
    val dutyName: String = "",
    val busNumber: String = "",
    val coworkerName: String = "",
    val coworkerBadge: String = "",
    val startTime: String = "",
    val endTime: String = "",
    val performedRole: String = "",
    val leaveType: String = "",
    val leaveReason: String = "",
    val creditId: String = "",
    val creditSourceDate: String = "",
    val notes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun entryTypeEnum(): EntryType = EntryType.fromName(entryType)
    fun leaveTypeEnum(): LeaveType? = LeaveType.fromNameOrNull(leaveType)
    fun performedRoleEnum(): DutyRole? = DutyRole.fromNameOrNull(performedRole)
}

@Keep
@IgnoreExtraProperties
data class LeaveCredit(
    @DocumentId val id: String = "",
    val userId: String = "",
    val creditType: String = CreditType.PH.name,
    val sourceDate: String = "",
    val sourceTitle: String = "",
    val expiresAtDate: String = "",
    val redeemed: Boolean = false,
    val redeemedOnDate: String = "",
    val sourceKind: String = CreditSourceKind.DEPOSITED.name,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun creditTypeEnum(): CreditType = CreditType.fromName(creditType)
    fun sourceKindEnum(): CreditSourceKind = CreditSourceKind.fromName(sourceKind)
}

data class PublicHoliday(
    val dateIso: String,
    val nameMr: String,
    val nameHi: String,
    val nameEn: String,
    val marathiMonthNote: String
)

data class UserPreferencesState(
    val language: AppLanguage = AppLanguage.MARATHI,
    val themeStyle: AppThemeStyle = AppThemeStyle.CRIMSON_GOLD,
    val darkMode: Boolean = false,
    val fontChoice: AppFontChoice = AppFontChoice.NOTO_DEVANAGARI,
    val fontSizeScale: FontSizeScale = FontSizeScale.MEDIUM,
    val localPinHash: String = "",
    val localPinSalt: String = "",
    val savedLoginContact: String = "",
    val pinVerifiedForSession: Boolean = false
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
