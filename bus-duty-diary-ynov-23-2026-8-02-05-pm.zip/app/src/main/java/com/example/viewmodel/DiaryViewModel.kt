package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DiaryRepository
import com.example.data.PreferencesManager
import com.example.model.DiaryEntry
import com.example.model.EmployeeProfile
import com.example.model.LeaveCredit
import com.example.model.UiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DiaryViewModel(
    private val repository: DiaryRepository,
    private val preferencesManager: PreferencesManager,
    val currentUserId: String
) : ViewModel() {

    val profileState: StateFlow<UiState<EmployeeProfile?>> = repository.observeProfile()
        .map<EmployeeProfile?, UiState<EmployeeProfile?>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing profile", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load profile"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val entriesState: StateFlow<UiState<List<DiaryEntry>>> = repository.observeDiaryEntries()
        .map<List<DiaryEntry>, UiState<List<DiaryEntry>>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing diary entries", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load diary entries"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val creditsState: StateFlow<UiState<List<LeaveCredit>>> = repository.observeLeaveCredits()
        .map<List<LeaveCredit>, UiState<List<LeaveCredit>>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing leave credits", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load PH / C-Off credits"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _snackbarMessage = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

    fun saveProfile(
        profile: EmployeeProfile,
        existingExists: Boolean,
        successMsg: String
    ) {
        viewModelScope.launch {
            _isSaving.value = true
            val result = repository.saveProfile(profile, existingExists)
            _isSaving.value = false
            result.fold(
                onSuccess = { _snackbarMessage.tryEmit(successMsg) },
                onFailure = { _snackbarMessage.tryEmit(it.localizedMessage ?: "Failed to save profile") }
            )
        }
    }

    fun saveDiaryEntry(
        entry: DiaryEntry,
        existingEntry: DiaryEntry?,
        weeklyOffDay: Int,
        existingCredits: List<LeaveCredit>,
        successMsg: String
    ) {
        viewModelScope.launch {
            _isSaving.value = true
            val result = repository.saveDiaryEntry(entry, existingEntry, weeklyOffDay, existingCredits)
            _isSaving.value = false
            result.fold(
                onSuccess = { _snackbarMessage.tryEmit(successMsg) },
                onFailure = { _snackbarMessage.tryEmit(it.localizedMessage ?: "Failed to save entry") }
            )
        }
    }

    fun deleteDiaryEntry(entry: DiaryEntry, successMsg: String) {
        viewModelScope.launch {
            _isSaving.value = true
            val result = repository.deleteDiaryEntry(entry)
            _isSaving.value = false
            result.fold(
                onSuccess = { _snackbarMessage.tryEmit(successMsg) },
                onFailure = { _snackbarMessage.tryEmit(it.localizedMessage ?: "Failed to delete entry") }
            )
        }
    }

    fun depositPhCredit(dateIso: String, title: String, successMsg: String) {
        viewModelScope.launch {
            _isSaving.value = true
            val result = repository.depositPhCredit(dateIso, title)
            _isSaving.value = false
            result.fold(
                onSuccess = { _snackbarMessage.tryEmit(successMsg) },
                onFailure = { _snackbarMessage.tryEmit(it.localizedMessage ?: "Failed to deposit PH") }
            )
        }
    }

    fun syncNow(successMsg: String, offlineMsg: String) {
        viewModelScope.launch {
            _isSyncing.value = true
            val result = repository.syncPendingWrites()
            _isSyncing.value = false
            result.fold(
                onSuccess = { _snackbarMessage.tryEmit(successMsg) },
                onFailure = { _snackbarMessage.tryEmit(offlineMsg) }
            )
        }
    }

    fun logFeedback(message: String, channel: String) {
        viewModelScope.launch {
            repository.logFeedback(message, channel)
        }
    }

    fun resetSessionPinLock() {
        viewModelScope.launch {
            preferencesManager.setPinVerified(false)
        }
    }

    private companion object {
        const val TAG = "DiaryViewModel"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
