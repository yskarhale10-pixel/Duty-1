package com.example.data

import com.example.model.AppLanguage
import com.example.model.PublicHoliday

object PublicHolidaysData {

    val holidays: List<PublicHoliday> = listOf(
        // --- 2025 ---
        PublicHoliday("2025-01-26", "प्रजासत्ताक दिन", "गणतंत्र दिवस", "Republic Day", "माघ कृष्ण १२"),
        PublicHoliday("2025-02-19", "छत्रपती शिवाजी महाराज जयंती", "छत्रपति शिवाजी महाराज जयंती", "Chhatrapati Shivaji Maharaj Jayanti", "माघ कृष्ण ६"),
        PublicHoliday("2025-02-26", "महाशिवरात्री", "महाशिवरात्रि", "Mahashivratri", "माघ कृष्ण १३"),
        PublicHoliday("2025-03-14", "धूलिवंदन / होळी", "होली / धुलेंडी", "Holi (Dhulivandan)", "फाल्गुन पौर्णिमा"),
        PublicHoliday("2025-03-30", "गुढीपाडवा", "गुड़ी पड़वा", "Gudi Padwa", "चैत्र शुद्ध १"),
        PublicHoliday("2025-03-31", "रमजान ईद", "ईद-उल-फ़ित्र", "Eid-ul-Fitr", "चैत्र शुद्ध २"),
        PublicHoliday("2025-04-06", "रामनवमी", "रामनवमी", "Ram Navami", "चैत्र शुद्ध ९"),
        PublicHoliday("2025-04-14", "डॉ. बाबासाहेब आंबेडकर जयंती", "डॉ. आंबेडकर जयंती", "Dr. Ambedkar Jayanti", "चैत्र कृष्ण १"),
        PublicHoliday("2025-04-18", "गुड फ्रायडे", "गुड फ्राइडे", "Good Friday", "चैत्र कृष्ण ५"),
        PublicHoliday("2025-05-01", "महाराष्ट्र दिन / कामगार दिन", "महाराष्ट्र दिवस / मजदूर दिवस", "Maharashtra Day / Labour Day", "वैशाख शुद्ध ४"),
        PublicHoliday("2025-05-12", "बुद्ध पौर्णिमा", "बुद्ध पूर्णिमा", "Buddha Purnima", "वैशाख पौर्णिमा"),
        PublicHoliday("2025-06-07", "बकरी ईद", "बकरीद", "Bakri Eid", "ज्येष्ठ शुद्ध १२"),
        PublicHoliday("2025-07-06", "आषाढी एकादशी / मोहरम", "आषाढ़ी एकादशी / मुहर्रम", "Ashadhi Ekadashi / Muharram", "आषाढ शुद्ध ११"),
        PublicHoliday("2025-08-15", "स्वातंत्र्य दिन", "स्वतंत्रता दिवस", "Independence Day", "श्रावण कृष्ण ६"),
        PublicHoliday("2025-08-27", "गणेश चतुर्थी", "गणेश चतुर्थी", "Ganesh Chaturthi", "भाद्रपद शुद्ध ४"),
        PublicHoliday("2025-09-06", "अनंत चतुर्दशी", "अनंत चतुर्दशी", "Anant Chaturdashi", "भाद्रपद शुद्ध १४"),
        PublicHoliday("2025-10-02", "महात्मा गांधी जयंती / दसरा", "गांधी जयंती / दशहरा", "Gandhi Jayanti / Dussehra", "आश्विन शुद्ध १०"),
        PublicHoliday("2025-10-21", "दिवाळी (लक्ष्मीपूजन)", "दिवाली (लक्ष्मी पूजन)", "Diwali (Laxmi Pujan)", "कार्तिक अमावस्या"),
        PublicHoliday("2025-10-22", "बलिप्रतिपदा (दिवाळी पाडवा)", "बलिप्रतिपदा / गोवर्धन पूजा", "Diwali Balipratipada", "कार्तिक शुद्ध १"),
        PublicHoliday("2025-11-05", "गुरुनानक जयंती", "गुरु नानक जयंती", "Guru Nanak Jayanti", "कार्तिक पौर्णिमा"),
        PublicHoliday("2025-12-25", "ख्रिसमस (नाताळ)", "क्रिसमस", "Christmas", "पौष शुद्ध ५"),

        // --- 2026 ---
        PublicHoliday("2026-01-26", "प्रजासत्ताक दिन", "गणतंत्र दिवस", "Republic Day", "माघ शुद्ध ८"),
        PublicHoliday("2026-02-15", "महाशिवरात्री", "महाशिवरात्रि", "Mahashivratri", "माघ कृष्ण १३"),
        PublicHoliday("2026-02-19", "छत्रपती शिवाजी महाराज जयंती", "छत्रपति शिवाजी महाराज जयंती", "Chhatrapati Shivaji Maharaj Jayanti", "फाल्गुन शुद्ध २"),
        PublicHoliday("2026-03-03", "होळी / धूलिवंदन", "होली / धुलेंडी", "Holi (Dhulivandan)", "फाल्गुन पौर्णिमा"),
        PublicHoliday("2026-03-19", "गुढीपाडवा", "गुड़ी पड़वा", "Gudi Padwa", "चैत्र शुद्ध १"),
        PublicHoliday("2026-03-21", "रमजान ईद", "ईद-उल-फ़ित्र", "Eid-ul-Fitr", "चैत्र शुद्ध ३"),
        PublicHoliday("2026-03-26", "रामनवमी", "रामनवमी", "Ram Navami", "चैत्र शुद्ध ८"),
        PublicHoliday("2026-03-31", "महावीर जयंती", "महावीर जयंती", "Mahavir Jayanti", "चैत्र शुद्ध १३"),
        PublicHoliday("2026-04-03", "गुड फ्रायडे", "गुड फ्राइडे", "Good Friday", "चैत्र कृष्ण १"),
        PublicHoliday("2026-04-14", "डॉ. बाबासाहेब आंबेडकर जयंती", "डॉ. आंबेडकर जयंती", "Dr. Ambedkar Jayanti", "चैत्र कृष्ण १२"),
        PublicHoliday("2026-05-01", "महाराष्ट्र दिन / बुद्ध पौर्णिमा", "महाराष्ट्र दिवस / बुद्ध पूर्णिमा", "Maharashtra Day / Buddha Purnima", "वैशाख पौर्णिमा"),
        PublicHoliday("2026-05-27", "बकरी ईद", "बकरीद", "Bakri Eid", "ज्येष्ठ शुद्ध ११"),
        PublicHoliday("2026-06-26", "मोहरम", "मुहर्रम", "Muharram", "ज्येष्ठ शुद्ध ११"),
        PublicHoliday("2026-07-25", "आषाढी एकादशी", "आषाढ़ी एकादशी", "Ashadhi Ekadashi", "आषाढ शुद्ध ११"),
        PublicHoliday("2026-08-15", "स्वातंत्र्य दिन", "स्वतंत्रता दिवस", "Independence Day", "श्रावण शुद्ध २"),
        PublicHoliday("2026-08-26", "ईद-ए-मिलाद", "ईद-ए-मिलाद", "Eid-e-Milad", "श्रावण शुद्ध १३"),
        PublicHoliday("2026-09-14", "गणेश चतुर्थी", "गणेश चतुर्थी", "Ganesh Chaturthi", "भाद्रपद शुद्ध ४"),
        PublicHoliday("2026-09-25", "अनंत चतुर्दशी", "अनंत चतुर्दशी", "Anant Chaturdashi", "भाद्रपद शुद्ध १४"),
        PublicHoliday("2026-10-02", "महात्मा गांधी जयंती", "महात्मा गांधी जयंती", "Mahatma Gandhi Jayanti", "आश्विन कृष्ण ६"),
        PublicHoliday("2026-10-20", "दसरा (विजयादशमी)", "दशहरा (विजयादशमी)", "Dussehra (Vijayadashami)", "आश्विन शुद्ध १०"),
        PublicHoliday("2026-11-08", "दिवाळी (लक्ष्मीपूजन)", "दिवाली (लक्ष्मी पूजन)", "Diwali (Laxmi Pujan)", "कार्तिक अमावस्या"),
        PublicHoliday("2026-11-10", "बलिप्रतिपदा (दिवाळी पाडवा)", "बलिप्रतिपदा / गोवर्धन पूजा", "Diwali Balipratipada", "कार्तिक शुद्ध १"),
        PublicHoliday("2026-11-11", "भाऊबीज", "भाई दूज", "Bhau Beej", "कार्तिक शुद्ध २"),
        PublicHoliday("2026-11-24", "गुरुनानक जयंती", "गुरु नानक जयंती", "Guru Nanak Jayanti", "कार्तिक पौर्णिमा"),
        PublicHoliday("2026-12-25", "ख्रिसमस (नाताळ)", "क्रिसमस", "Christmas", "मार्गशीर्ष कृष्ण १"),

        // --- 2027 ---
        PublicHoliday("2027-01-26", "प्रजासत्ताक दिन", "गणतंत्र दिवस", "Republic Day", "माघ कृष्ण ४"),
        PublicHoliday("2027-02-19", "छत्रपती शिवाजी महाराज जयंती", "छत्रपति शिवाजी महाराज जयंती", "Chhatrapati Shivaji Maharaj Jayanti", "माघ शुद्ध १३"),
        PublicHoliday("2027-03-06", "महाशिवरात्री", "महाशिवरात्रि", "Mahashivratri", "माघ कृष्ण १३"),
        PublicHoliday("2027-03-10", "रमजान ईद", "ईद-उल-फ़ित्र", "Eid-ul-Fitr", "फाल्गुन शुद्ध ३"),
        PublicHoliday("2027-03-22", "धूलिवंदन / होळी", "होली", "Holi (Dhulivandan)", "फाल्गुन पौर्णिमा"),
        PublicHoliday("2027-03-26", "गुड फ्रायडे", "गुड फ्राइडे", "Good Friday", "चैत्र कृष्ण ४"),
        PublicHoliday("2027-04-07", "गुढीपाडवा", "गुड़ी पड़वा", "Gudi Padwa", "चैत्र शुद्ध १"),
        PublicHoliday("2027-04-14", "डॉ. आंबेडकर जयंती", "डॉ. आंबेडकर जयंती", "Dr. Ambedkar Jayanti", "चैत्र शुद्ध ८"),
        PublicHoliday("2027-04-15", "रामनवमी", "रामनवमी", "Ram Navami", "चैत्र शुद्ध ९"),
        PublicHoliday("2027-05-01", "महाराष्ट्र दिन", "महाराष्ट्र दिवस", "Maharashtra Day", "चैत्र कृष्ण १०"),
        PublicHoliday("2027-05-20", "बुद्ध पौर्णिमा", "बुद्ध पूर्णिमा", "Buddha Purnima", "वैशाख पौर्णिमा"),
        PublicHoliday("2027-08-15", "स्वातंत्र्य दिन", "स्वतंत्रता दिवस", "Independence Day", "श्रावण शुद्ध १४"),
        PublicHoliday("2027-09-04", "गणेश चतुर्थी", "गणेश चतुर्थी", "Ganesh Chaturthi", "भाद्रपद शुद्ध ४"),
        PublicHoliday("2027-10-02", "महात्मा गांधी जयंती", "गांधी जयंती", "Mahatma Gandhi Jayanti", "आश्विन शुद्ध ३"),
        PublicHoliday("2027-10-10", "दसरा", "दशहरा", "Dussehra", "आश्विन शुद्ध १०"),
        PublicHoliday("2027-10-29", "दिवाळी (लक्ष्मीपूजन)", "दिवाली (लक्ष्मी पूजन)", "Diwali (Laxmi Pujan)", "कार्तिक अमावस्या"),
        PublicHoliday("2027-12-25", "ख्रिसमस (नाताळ)", "क्रिसमस", "Christmas", "मार्गशीर्ष कृष्ण १२")
    )

    private val holidayByDate: Map<String, PublicHoliday> = holidays.associateBy { it.dateIso }

    fun getHoliday(dateIso: String): PublicHoliday? = holidayByDate[dateIso]

    fun holidaysForYear(year: Int): List<PublicHoliday> =
        holidays.filter { it.dateIso.startsWith("$year-") }

    fun holidaysForMonth(year: Int, month: Int): List<PublicHoliday> {
        val prefix = "%04d-%02d-".format(year, month)
        return holidays.filter { it.dateIso.startsWith(prefix) }
    }

    fun PublicHoliday.localizedName(lang: AppLanguage): String = when (lang) {
        AppLanguage.MARATHI -> nameMr
        AppLanguage.HINDI -> nameHi
        AppLanguage.ENGLISH -> nameEn
    }
}
