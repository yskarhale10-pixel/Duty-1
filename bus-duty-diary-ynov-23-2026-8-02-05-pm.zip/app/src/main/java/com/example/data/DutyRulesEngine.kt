package com.example.data

import com.example.model.CreditType
import com.example.model.DiaryEntry
import com.example.model.EntryType
import com.example.model.LeaveCredit
import java.time.LocalDate

data class BalanceSummary(
    val remainingPh: List<LeaveCredit>,
    val usedPh: List<LeaveCredit>,
    val expiredPh: List<LeaveCredit>,
    val remainingCOff: List<LeaveCredit>,
    val usedCOff: List<LeaveCredit>
)

data class ReportRow(
    val dateIso: String,
    val date: LocalDate,
    val category: ReportCategory,
    val title: String,
    val subtitle: String,
    val entry: DiaryEntry? = null
)

enum class ReportCategory {
    DUTY,
    LEAVE,
    WEEKLY_OFF,
    BROKEN_WEEKLY_OFF,
    PH_TAKEN,
    C_OFF_TAKEN
}

object DutyRulesEngine {

    fun parseDateOrNull(iso: String): LocalDate? = try {
        LocalDate.parse(iso)
    } catch (_: Exception) {
        null
    }

    fun isPublicHoliday(dateIso: String): Boolean =
        PublicHolidaysData.getHoliday(dateIso) != null

    fun isWeeklyOff(date: LocalDate, weeklyOffDay: Int): Boolean =
        weeklyOffDay in 1..7 && date.dayOfWeek.value == weeklyOffDay

    /**
     * Weekly Off Break rule:
     * If employee has LEAVE on the day before AND day after a Weekly Off (and did not work DUTY on the weekly off),
     * that Weekly Off is broken and treated as Leave.
     */
    fun isWeeklyOffBroken(
        date: LocalDate,
        weeklyOffDay: Int,
        entriesByDate: Map<String, DiaryEntry>
    ): Boolean {
        if (!isWeeklyOff(date, weeklyOffDay)) return false
        val ownEntry = entriesByDate[date.toString()]
        if (ownEntry != null && ownEntry.entryTypeEnum() == EntryType.DUTY) return false
        if (ownEntry != null && ownEntry.entryTypeEnum() == EntryType.LEAVE) return true

        val prevEntry = entriesByDate[date.minusDays(1).toString()]
        val nextEntry = entriesByDate[date.plusDays(1).toString()]
        return prevEntry?.entryTypeEnum() == EntryType.LEAVE &&
            nextEntry?.entryTypeEnum() == EntryType.LEAVE
    }

    /**
     * Checks if a PH credit can be redeemed on [targetDate].
     * - Must be >= sourceDate (cannot take PH before holiday date)
     * - Must be <= sourceDate.plusMonths(3) (expires after 3 months)
     * - targetDate must NOT be a Public Holiday or Weekly Off
     */
    fun isPhCreditValidForDate(
        credit: LeaveCredit,
        targetDate: LocalDate,
        weeklyOffDay: Int
    ): Boolean {
        if (credit.creditTypeEnum() != CreditType.PH || credit.redeemed) return false
        val targetIso = targetDate.toString()
        if (isPublicHoliday(targetIso) || isWeeklyOff(targetDate, weeklyOffDay)) return false
        val source = parseDateOrNull(credit.sourceDate) ?: return false
        val expiry = parseDateOrNull(credit.expiresAtDate) ?: source.plusMonths(3)
        return !targetDate.isBefore(source) && !targetDate.isAfter(expiry)
    }

    /**
     * Checks if a C-Off credit can be redeemed on [targetDate].
     * - Must be strictly AFTER sourceDate (cannot take C-Off before the worked Weekly Off)
     * - targetDate must NOT be a Public Holiday or Weekly Off
     */
    fun isCOffCreditValidForDate(
        credit: LeaveCredit,
        targetDate: LocalDate,
        weeklyOffDay: Int
    ): Boolean {
        if (credit.creditTypeEnum() != CreditType.C_OFF || credit.redeemed) return false
        val targetIso = targetDate.toString()
        if (isPublicHoliday(targetIso) || isWeeklyOff(targetDate, weeklyOffDay)) return false
        val source = parseDateOrNull(credit.sourceDate) ?: return false
        return targetDate.isAfter(source)
    }

    fun isPhExpired(credit: LeaveCredit, referenceDate: LocalDate = LocalDate.now()): Boolean {
        if (credit.creditTypeEnum() != CreditType.PH || credit.redeemed) return false
        val source = parseDateOrNull(credit.sourceDate) ?: return false
        val expiry = parseDateOrNull(credit.expiresAtDate) ?: source.plusMonths(3)
        return referenceDate.isAfter(expiry)
    }

    fun computeBalances(
        credits: List<LeaveCredit>,
        referenceDate: LocalDate = LocalDate.now()
    ): BalanceSummary {
        val phCredits = credits.filter { it.creditTypeEnum() == CreditType.PH }
        val cOffCredits = credits.filter { it.creditTypeEnum() == CreditType.C_OFF }

        val usedPh = phCredits.filter { it.redeemed }
        val expiredPh = phCredits.filter { !it.redeemed && isPhExpired(it, referenceDate) }
        val remainingPh = phCredits.filter { !it.redeemed && !isPhExpired(it, referenceDate) }

        val usedCOff = cOffCredits.filter { it.redeemed }
        val remainingCOff = cOffCredits.filter { !it.redeemed }

        return BalanceSummary(
            remainingPh = remainingPh.sortedBy { it.sourceDate },
            usedPh = usedPh.sortedByDescending { it.redeemedOnDate },
            expiredPh = expiredPh.sortedByDescending { it.sourceDate },
            remainingCOff = remainingCOff.sortedBy { it.sourceDate },
            usedCOff = usedCOff.sortedByDescending { it.redeemedOnDate }
        )
    }

    /**
     * Builds chronological report rows strictly up to [today] (never includes future dates).
     */
    fun buildReportRows(
        startDate: LocalDate,
        endDate: LocalDate,
        today: LocalDate,
        weeklyOffDay: Int,
        entries: List<DiaryEntry>
    ): List<ReportRow> {
        val cappedEnd = if (endDate.isAfter(today)) today else endDate
        if (cappedEnd.isBefore(startDate)) return emptyList()

        val entriesByDate = entries.associateBy { it.dateIso }
        val rows = mutableListOf<ReportRow>()

        var cursor = startDate
        while (!cursor.isAfter(cappedEnd)) {
            val iso = cursor.toString()
            val entry = entriesByDate[iso]
            val isWo = isWeeklyOff(cursor, weeklyOffDay)

            when {
                entry != null -> {
                    when (entry.entryTypeEnum()) {
                        EntryType.DUTY -> {
                            val roleSuffix = if (entry.performedRole.isNotBlank()) " (${entry.performedRole})" else ""
                            rows += ReportRow(
                                dateIso = iso,
                                date = cursor,
                                category = ReportCategory.DUTY,
                                title = "#${entry.dutyNumber.ifBlank { "-" }} ${entry.dutyName}$roleSuffix".trim(),
                                subtitle = listOfNotNull(
                                    entry.busNumber.takeIf { it.isNotBlank() }?.let { "Bus: $it" },
                                    entry.startTime.takeIf { it.isNotBlank() }?.let { "$it - ${entry.endTime}" },
                                    entry.coworkerName.takeIf { it.isNotBlank() }?.let { "$it (${entry.coworkerBadge})" }
                                ).joinToString(" | "),
                                entry = entry
                            )
                        }
                        EntryType.LEAVE -> {
                            rows += ReportRow(
                                dateIso = iso,
                                date = cursor,
                                category = ReportCategory.LEAVE,
                                title = entry.leaveTypeEnum()?.code ?: "LEAVE",
                                subtitle = entry.leaveReason,
                                entry = entry
                            )
                        }
                        EntryType.PH -> {
                            rows += ReportRow(
                                dateIso = iso,
                                date = cursor,
                                category = ReportCategory.PH_TAKEN,
                                title = "PH",
                                subtitle = entry.creditSourceDate.takeIf { it.isNotBlank() }?.let { "Against: $it" } ?: "",
                                entry = entry
                            )
                        }
                        EntryType.C_OFF -> {
                            rows += ReportRow(
                                dateIso = iso,
                                date = cursor,
                                category = ReportCategory.C_OFF_TAKEN,
                                title = "C-Off",
                                subtitle = entry.creditSourceDate.takeIf { it.isNotBlank() }?.let { "Against WO: $it" } ?: "",
                                entry = entry
                            )
                        }
                    }
                }
                isWo -> {
                    val broken = isWeeklyOffBroken(cursor, weeklyOffDay, entriesByDate)
                    rows += ReportRow(
                        dateIso = iso,
                        date = cursor,
                        category = if (broken) ReportCategory.BROKEN_WEEKLY_OFF else ReportCategory.WEEKLY_OFF,
                        title = if (broken) "Weekly Off Broken (Leave)" else "Weekly Off",
                        subtitle = if (broken) "Leave before & after Weekly Off" else "Scheduled Weekly Off"
                    )
                }
            }
            cursor = cursor.plusDays(1)
        }
        return rows.sortedByDescending { it.date }
    }
}
