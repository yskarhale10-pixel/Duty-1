package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppFontChoice
import com.example.model.AppLanguage
import com.example.model.AppThemeStyle
import com.example.model.FontSizeScale
import com.example.model.UserPreferencesState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.diaryDataStore: DataStore<Preferences> by preferencesDataStore(name = "bus_duty_diary_prefs")

class PreferencesManager(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("language_code")
        val THEME_STYLE = stringPreferencesKey("theme_style")
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val FONT_CHOICE = stringPreferencesKey("font_choice")
        val FONT_SCALE = stringPreferencesKey("font_scale")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val PIN_SALT = stringPreferencesKey("pin_salt")
        val SAVED_CONTACT = stringPreferencesKey("saved_contact")
        val PIN_VERIFIED = booleanPreferencesKey("pin_verified")
    }

    val preferencesFlow: Flow<UserPreferencesState> = context.diaryDataStore.data.map { prefs ->
        UserPreferencesState(
            language = AppLanguage.fromCode(prefs[Keys.LANGUAGE]),
            themeStyle = AppThemeStyle.fromName(prefs[Keys.THEME_STYLE]),
            darkMode = prefs[Keys.DARK_MODE] ?: false,
            fontChoice = AppFontChoice.fromName(prefs[Keys.FONT_CHOICE]),
            fontSizeScale = FontSizeScale.fromName(prefs[Keys.FONT_SCALE]),
            localPinHash = prefs[Keys.PIN_HASH] ?: "",
            localPinSalt = prefs[Keys.PIN_SALT] ?: "",
            savedLoginContact = prefs[Keys.SAVED_CONTACT] ?: "",
            pinVerifiedForSession = prefs[Keys.PIN_VERIFIED] ?: false
        )
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.diaryDataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun setThemeStyle(style: AppThemeStyle) {
        context.diaryDataStore.edit { it[Keys.THEME_STYLE] = style.name }
    }

    suspend fun setDarkMode(enabled: Boolean) {
        context.diaryDataStore.edit { it[Keys.DARK_MODE] = enabled }
    }

    suspend fun setFontChoice(fontChoice: AppFontChoice) {
        context.diaryDataStore.edit { it[Keys.FONT_CHOICE] = fontChoice.name }
    }

    suspend fun setFontSizeScale(scale: FontSizeScale) {
        context.diaryDataStore.edit { it[Keys.FONT_SCALE] = scale.name }
    }

    suspend fun savePinCredentials(contact: String, hash: String, salt: String) {
        context.diaryDataStore.edit {
            it[Keys.SAVED_CONTACT] = contact
            it[Keys.PIN_HASH] = hash
            it[Keys.PIN_SALT] = salt
            it[Keys.PIN_VERIFIED] = true
        }
    }

    suspend fun setPinVerified(verified: Boolean, contact: String? = null) {
        context.diaryDataStore.edit {
            it[Keys.PIN_VERIFIED] = verified
            if (contact != null) {
                it[Keys.SAVED_CONTACT] = contact
            }
        }
    }
}
