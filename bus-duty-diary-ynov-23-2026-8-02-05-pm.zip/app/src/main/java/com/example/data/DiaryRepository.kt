package com.example.data

import android.content.Context
import com.example.R
import com.example.model.CreditSourceKind
import com.example.model.CreditType
import com.example.model.DiaryEntry
import com.example.model.EmployeeProfile
import com.example.model.EntryType
import com.example.model.LeaveCredit
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.PersistentCacheSettings
import com.google.firebase.firestore.firestoreSettings
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.time.LocalDate

object FirestoreProvider {
    @Volatile
    private var configured = false

    fun getDatabase(context: Context): FirebaseFirestore {
        val dbId = context.applicationContext.getString(R.string.firestore_database_id)
        val db = FirebaseFirestore.getInstance(dbId)
        if (!configured) {
            synchronized(this) {
                if (!configured) {
                    try {
                        val settings = firestoreSettings {
                            setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
                        }
                        db.firestoreSettings = settings
                    } catch (_: IllegalStateException) {
                        // Already configured prior to first access; safe to continue.
                    }
                    configured = true
                }
            }
        }
        return db
    }
}

class DiaryRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(FirestoreProvider.getDatabase(context))

    private fun requireUserId(): String =
        auth.currentUser?.uid?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    fun observeProfile(): Flow<EmployeeProfile?> = flow {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            EmployeeProfile::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else null
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, docRef.path)
                    }
                    throw error
                }
        )
    }

    fun observeDiaryEntries(): Flow<List<DiaryEntry>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/diary_entries"
        emitAll(
            db.collection("users").document(uid).collection("diary_entries")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        DiaryEntry::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeLeaveCredits(): Flow<List<LeaveCredit>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/leave_credits"
        emitAll(
            db.collection("users").document(uid).collection("leave_credits")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        LeaveCredit::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun saveProfile(profile: EmployeeProfile, existingExists: Boolean): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid)
            docPath = docRef.path
            val safeName = profile.name.trim().take(80)
            val safeEmail = profile.email.trim().take(120)
            val safeMobile = profile.mobile.trim().take(20)
            val safeDob = profile.dateOfBirth.trim().take(20)
            val safePhoto = profile.photoUri.trim().take(500)
            val safeOff = profile.weeklyOffDay.coerceIn(0, 7)

            if (existingExists) {
                val updatePayload = mutableMapOf<String, Any>(
                    "name" to safeName,
                    "email" to safeEmail,
                    "mobile" to safeMobile,
                    "dateOfBirth" to safeDob,
                    "designation" to profile.designation,
                    "weeklyOffDay" to safeOff,
                    "photoUri" to safePhoto,
                    "profileSubmitted" to profile.profileSubmitted,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (profile.pinHash.isNotBlank() && profile.pinSalt.isNotBlank()) {
                    updatePayload["pinHash"] = profile.pinHash.take(128)
                    updatePayload["pinSalt"] = profile.pinSalt.take(64)
                }
                docRef.update(updatePayload).await()
            } else {
                val createPayload = mutableMapOf<String, Any>(
                    "userId" to uid,
                    "name" to safeName,
                    "email" to safeEmail,
                    "mobile" to safeMobile,
                    "dateOfBirth" to safeDob,
                    "designation" to profile.designation,
                    "weeklyOffDay" to safeOff,
                    "photoUri" to safePhoto,
                    "profileSubmitted" to profile.profileSubmitted,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (profile.pinHash.isNotBlank() && profile.pinSalt.isNotBlank()) {
                    createPayload["pinHash"] = profile.pinHash.take(128)
                    createPayload["pinSalt"] = profile.pinSalt.take(64)
                }
                docRef.set(createPayload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun savePinToProfile(pinHash: String, pinSalt: String, emailOrMobile: String): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid)
            docPath = docRef.path
            val snap = docRef.get().await()
            if (snap.exists()) {
                docRef.update(
                    mapOf(
                        "pinHash" to pinHash.take(128),
                        "pinSalt" to pinSalt.take(64),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                val fallbackEmail = if (emailOrMobile.contains("@")) emailOrMobile else (auth.currentUser?.email ?: "")
                val fallbackMobile = if (!emailOrMobile.contains("@")) emailOrMobile else ""
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "name" to (auth.currentUser?.displayName ?: "").take(80),
                        "email" to fallbackEmail.take(120),
                        "mobile" to fallbackMobile.take(20),
                        "dateOfBirth" to "",
                        "designation" to "DRIVER",
                        "weeklyOffDay" to 0,
                        "photoUri" to "",
                        "profileSubmitted" to false,
                        "pinHash" to pinHash.take(128),
                        "pinSalt" to pinSalt.take(64),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun saveDiaryEntry(
        entry: DiaryEntry,
        existingEntry: DiaryEntry?,
        weeklyOffDay: Int,
        existingCredits: List<LeaveCredit>
    ): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/diary_entries/${entry.dateIso}"
        return try {
            val uid = requireUserId()
            require(entry.dateIso.matches(Regex("^\\d{4}-\\d{2}-\\d{2}$"))) { "Invalid ISO date" }
            val docRef = db.collection("users").document(uid)
                .collection("diary_entries").document(entry.dateIso)
            docPath = docRef.path

            if (existingEntry != null) {
                docRef.update(
                    mapOf(
                        "entryType" to entry.entryType,
                        "dutyNumber" to entry.dutyNumber.take(40),
                        "dutyName" to entry.dutyName.take(100),
                        "busNumber" to entry.busNumber.take(40),
                        "coworkerName" to entry.coworkerName.take(80),
                        "coworkerBadge" to entry.coworkerBadge.take(40),
                        "startTime" to entry.startTime.take(20),
                        "endTime" to entry.endTime.take(20),
                        "performedRole" to entry.performedRole,
                        "leaveType" to entry.leaveType,
                        "leaveReason" to entry.leaveReason.take(300),
                        "creditId" to entry.creditId.take(128),
                        "creditSourceDate" to entry.creditSourceDate.take(20),
                        "notes" to entry.notes.take(300),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "dateIso" to entry.dateIso,
                        "entryType" to entry.entryType,
                        "dutyNumber" to entry.dutyNumber.take(40),
                        "dutyName" to entry.dutyName.take(100),
                        "busNumber" to entry.busNumber.take(40),
                        "coworkerName" to entry.coworkerName.take(80),
                        "coworkerBadge" to entry.coworkerBadge.take(40),
                        "startTime" to entry.startTime.take(20),
                        "endTime" to entry.endTime.take(20),
                        "performedRole" to entry.performedRole,
                        "leaveType" to entry.leaveType,
                        "leaveReason" to entry.leaveReason.take(300),
                        "creditId" to entry.creditId.take(128),
                        "creditSourceDate" to entry.creditSourceDate.take(20),
                        "notes" to entry.notes.take(300),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            // Release previous credit if the old entry redeemed a PH/C-Off and was changed
            if (existingEntry != null && existingEntry.creditId.isNotBlank() && existingEntry.creditId != entry.creditId) {
                val oldCreditRef = db.collection("users").document(uid)
                    .collection("leave_credits").document(existingEntry.creditId)
                val oldSnap = oldCreditRef.get().await()
                if (oldSnap.exists()) {
                    oldCreditRef.update(
                        mapOf(
                            "redeemed" to false,
                            "redeemedOnDate" to "",
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }

            // Redeem chosen credit if saving PH or C_OFF
            if ((entry.entryTypeEnum() == EntryType.PH || entry.entryTypeEnum() == EntryType.C_OFF) &&
                entry.creditId.isNotBlank()
            ) {
                val creditRef = db.collection("users").document(uid)
                    .collection("leave_credits").document(entry.creditId)
                creditRef.update(
                    mapOf(
                        "redeemed" to true,
                        "redeemedOnDate" to entry.dateIso,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            // Auto-earn PH or C-Off when DUTY is logged on a Public Holiday or Weekly Off
            if (entry.entryTypeEnum() == EntryType.DUTY) {
                val date = LocalDate.parse(entry.dateIso)
                val holiday = PublicHolidaysData.getHoliday(entry.dateIso)
                if (holiday != null) {
                    val phCreditId = "ph_${entry.dateIso}"
                    val alreadyHas = existingCredits.any { it.id == phCreditId }
                    if (!alreadyHas) {
                        val expiry = date.plusMonths(3).toString()
                        db.collection("users").document(uid)
                            .collection("leave_credits").document(phCreditId)
                            .set(
                                mapOf(
                                    "userId" to uid,
                                    "creditType" to CreditType.PH.name,
                                    "sourceDate" to entry.dateIso,
                                    "sourceTitle" to holiday.nameMr.take(120),
                                    "expiresAtDate" to expiry,
                                    "redeemed" to false,
                                    "redeemedOnDate" to "",
                                    "sourceKind" to CreditSourceKind.EARNED_DUTY.name,
                                    "createdAt" to FieldValue.serverTimestamp(),
                                    "updatedAt" to FieldValue.serverTimestamp()
                                )
                            ).await()
                    }
                }
                if (DutyRulesEngine.isWeeklyOff(date, weeklyOffDay)) {
                    val cOffId = "coff_${entry.dateIso}"
                    val alreadyHas = existingCredits.any { it.id == cOffId }
                    if (!alreadyHas) {
                        db.collection("users").document(uid)
                            .collection("leave_credits").document(cOffId)
                            .set(
                                mapOf(
                                    "userId" to uid,
                                    "creditType" to CreditType.C_OFF.name,
                                    "sourceDate" to entry.dateIso,
                                    "sourceTitle" to "Weekly Off Duty (${entry.dateIso})",
                                    "expiresAtDate" to "",
                                    "redeemed" to false,
                                    "redeemedOnDate" to "",
                                    "sourceKind" to CreditSourceKind.EARNED_DUTY.name,
                                    "createdAt" to FieldValue.serverTimestamp(),
                                    "updatedAt" to FieldValue.serverTimestamp()
                                )
                            ).await()
                    }
                }
            }

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteDiaryEntry(entry: DiaryEntry): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/diary_entries/${entry.dateIso}"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid)
                .collection("diary_entries").document(entry.dateIso)
            docPath = docRef.path
            docRef.delete().await()

            if (entry.creditId.isNotBlank()) {
                val creditRef = db.collection("users").document(uid)
                    .collection("leave_credits").document(entry.creditId)
                val snap = creditRef.get().await()
                if (snap.exists()) {
                    creditRef.update(
                        mapOf(
                            "redeemed" to false,
                            "redeemedOnDate" to "",
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun depositPhCredit(dateIso: String, title: String): Result<Unit> {
        val creditId = "ph_$dateIso"
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/leave_credits/$creditId"
        return try {
            val uid = requireUserId()
            val date = LocalDate.parse(dateIso)
            val expiry = date.plusMonths(3).toString()
            val docRef = db.collection("users").document(uid)
                .collection("leave_credits").document(creditId)
            docPath = docRef.path
            val snap = docRef.get().await()
            if (!snap.exists()) {
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "creditType" to CreditType.PH.name,
                        "sourceDate" to dateIso,
                        "sourceTitle" to title.take(120),
                        "expiresAtDate" to expiry,
                        "redeemed" to false,
                        "redeemedOnDate" to "",
                        "sourceKind" to CreditSourceKind.DEPOSITED.name,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun logFeedback(message: String, channel: String): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/feedback"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid).collection("feedback").document()
            docPath = docRef.path
            docRef.set(
                mapOf(
                    "userId" to uid,
                    "message" to message.trim().take(500),
                    "channel" to channel,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun syncPendingWrites(): Result<Unit> {
        return try {
            requireUserId()
            db.waitForPendingWrites().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "waitForPendingWrites")
            Result.failure(e)
        }
    }
}
