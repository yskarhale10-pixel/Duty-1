package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.localization.AppStrings
import com.example.localization.dayOfWeekLabel
import com.example.localization.shortDayLabel
import com.example.model.AppLanguage
import com.example.model.Designation
import com.example.model.EmployeeProfile
import com.example.ui.theme.StatusWeeklyOffBg
import com.example.ui.theme.StatusWeeklyOffFg
import com.example.util.PhotoStorageHelper
import java.io.File
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneId

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    strings: AppStrings,
    language: AppLanguage,
    currentUserId: String,
    profile: EmployeeProfile?,
    isSaving: Boolean,
    onSaveProfile: (EmployeeProfile, Boolean) -> Unit,
    onLogoutClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val existingExists = profile != null

    var name by remember(profile?.userId) { mutableStateOf(profile?.name ?: "") }
    var dateOfBirth by remember(profile?.userId) { mutableStateOf(profile?.dateOfBirth ?: "") }
    var designation by remember(profile?.userId) {
        mutableStateOf(profile?.designationEnum() ?: Designation.DRIVER)
    }
    var weeklyOffDay by remember(profile?.userId) { mutableIntStateOf(profile?.weeklyOffDay ?: 0) }
    var mobile by remember(profile?.userId) { mutableStateOf(profile?.mobile ?: "") }
    var photoUri by remember(profile?.userId) { mutableStateOf(profile?.photoUri ?: "") }
    var profileSubmitted by remember(profile?.userId) {
        mutableStateOf(profile?.profileSubmitted ?: false)
    }
    var isEditing by remember(profile?.userId) {
        mutableStateOf(!(profile?.profileSubmitted ?: false))
    }

    LaunchedEffect(profile) {
        if (profile != null) {
            if (name.isBlank() && profile.name.isNotBlank()) name = profile.name
            if (dateOfBirth.isBlank() && profile.dateOfBirth.isNotBlank()) dateOfBirth = profile.dateOfBirth
            if (mobile.isBlank() && profile.mobile.isNotBlank()) mobile = profile.mobile
            if (weeklyOffDay == 0 && profile.weeklyOffDay in 1..7) weeklyOffDay = profile.weeklyOffDay
            if (photoUri.isBlank() && profile.photoUri.isNotBlank()) photoUri = profile.photoUri
            profileSubmitted = profile.profileSubmitted
            if (profile.profileSubmitted) isEditing = false
        }
    }

    var showDobPicker by remember { mutableStateOf(false) }
    var showWeeklyOffCalendarPicker by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                val localPath = PhotoStorageHelper.persistPickedPhotoLocally(context, uri, currentUserId)
                photoUri = localPath ?: uri.toString()
            }
        }
    )

    val draftProfile = EmployeeProfile(
        userId = currentUserId,
        name = name.trim(),
        email = profile?.email ?: "",
        mobile = mobile.filter { it.isDigit() }.take(15),
        dateOfBirth = dateOfBirth.trim(),
        designation = designation.name,
        weeklyOffDay = weeklyOffDay,
        photoUri = photoUri,
        profileSubmitted = profileSubmitted,
        pinHash = profile?.pinHash ?: "",
        pinSalt = profile?.pinSalt ?: ""
    )

    val isComplete = draftProfile.isComplete()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Heading + Submitted Badge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = strings.profileHeading,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            if (profileSubmitted) {
                Surface(
                    color = Color(0xFFDDF6E4),
                    shape = RoundedCornerShape(50)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF0F6B36),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = strings.profileSubmittedBadge,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF0F6B36),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Photo Picker Card
        Card(
            shape = MaterialTheme.shapes.medium,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                        .clickable(enabled = isEditing) {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    val photoModel: Any? = remember(photoUri) {
                        if (photoUri.isBlank()) null
                        else if (photoUri.startsWith("/")) File(photoUri)
                        else photoUri
                    }
                    if (photoModel != null) {
                        AsyncImage(
                            model = photoModel,
                            contentDescription = strings.employeeNameLabel,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.Person,
                            contentDescription = strings.employeeNameLabel,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                Spacer(Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = name.ifBlank { strings.employeeNameLabel },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        enabled = isEditing,
                        modifier = Modifier.testTag("pick_photo_button")
                    ) {
                        Icon(Icons.Filled.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (photoUri.isBlank()) strings.addPhotoBtn else strings.changePhotoBtn)
                    }
                }
            }
        }

        // Form Details Card
        Card(
            shape = MaterialTheme.shapes.medium,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 2. Employee Name
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    enabled = isEditing,
                    label = { Text(strings.employeeNameLabel) },
                    leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_name_input")
                )

                // 3. Date of Birth
                OutlinedTextField(
                    value = dateOfBirth,
                    onValueChange = {},
                    readOnly = true,
                    enabled = isEditing,
                    label = { Text(strings.dobLabel) },
                    placeholder = { Text(strings.selectDobHint) },
                    leadingIcon = { Icon(Icons.Filled.Cake, contentDescription = null) },
                    trailingIcon = {
                        TextButton(
                            onClick = { if (isEditing) showDobPicker = true },
                            enabled = isEditing
                        ) {
                            Text(strings.selectDate)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = isEditing) { showDobPicker = true }
                        .testTag("profile_dob_input")
                )

                // 4. Employee Designation (Driver / Conductor / Driver cum Conductor)
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Badge,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = strings.designationLabel,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Designation.entries.forEach { role ->
                            val selected = designation == role
                            val label = when (language) {
                                AppLanguage.MARATHI -> role.labelMr
                                AppLanguage.HINDI -> role.labelHi
                                AppLanguage.ENGLISH -> role.labelEn
                            }
                            FilterChip(
                                selected = selected,
                                enabled = isEditing,
                                onClick = { designation = role },
                                label = { Text(label, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
                                modifier = Modifier.testTag("designation_chip_${role.name}")
                            )
                        }
                    }
                    if (designation == Designation.DRIVER_CUM_CONDUCTOR) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp)
                        ) {
                            Text(
                                text = strings.driverCumConductorNote,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }

                // 5. Weekly Off Picker (Calendar + Distinct Color Chips)
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.CalendarMonth,
                                contentDescription = null,
                                tint = StatusWeeklyOffFg,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = strings.weeklyOffLabel,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        TextButton(
                            onClick = { if (isEditing) showWeeklyOffCalendarPicker = true },
                            enabled = isEditing,
                            modifier = Modifier.testTag("weekly_off_calendar_btn")
                        ) {
                            Text(strings.selectDate)
                        }
                    }
                    if (weeklyOffDay !in 1..7) {
                        Text(
                            text = strings.selectWeeklyOffHint,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        val selectedDay = DayOfWeek.of(weeklyOffDay)
                        Surface(
                            color = StatusWeeklyOffBg,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.padding(bottom = 6.dp)
                        ) {
                            Text(
                                text = "${strings.weeklyOffLabel}: ${dayOfWeekLabel(selectedDay, language)}",
                                style = MaterialTheme.typography.labelLarge,
                                color = StatusWeeklyOffFg,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        DayOfWeek.entries.forEach { day ->
                            val selected = weeklyOffDay == day.value
                            FilterChip(
                                selected = selected,
                                enabled = isEditing,
                                onClick = { weeklyOffDay = day.value },
                                label = {
                                    Text(
                                        text = shortDayLabel(day, language),
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StatusWeeklyOffBg,
                                    selectedLabelColor = StatusWeeklyOffFg
                                ),
                                modifier = Modifier.testTag("weekly_off_day_${day.value}")
                            )
                        }
                    }
                }

                // 6. Mobile Number
                OutlinedTextField(
                    value = mobile,
                    onValueChange = { val filtered = it.filter { c -> c.isDigit() }.take(10); mobile = filtered },
                    enabled = isEditing,
                    label = { Text(strings.mobileLabel) },
                    leadingIcon = { Icon(Icons.Filled.Phone, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_mobile_input")
                )
            }
        }

        // Bottom Submit / Logout Button Rules:
        // Hidden if profile info is incomplete!
        // Shown as Submit when complete & not submitted; shown as Logout after Submit!
        if (!isComplete) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = strings.profileIncompleteHint,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(12.dp)
                )
            }
        } else {
            if (!profileSubmitted || isEditing) {
                Button(
                    onClick = {
                        profileSubmitted = true
                        isEditing = false
                        onSaveProfile(draftProfile.copy(profileSubmitted = true), existingExists)
                    },
                    enabled = !isSaving,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("profile_submit_button")
                ) {
                    Text(strings.submitProfileBtn, fontWeight = FontWeight.Bold)
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { isEditing = true },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("profile_edit_button")
                    ) {
                        Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.editProfileBtn)
                    }

                    Button(
                        onClick = {
                            onSaveProfile(draftProfile.copy(profileSubmitted = false), existingExists)
                            onLogoutClicked()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("profile_logout_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.logoutBtn, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }

    if (showDobPicker) {
        val pickerState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showDobPicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        pickerState.selectedDateMillis?.let { millis ->
                            val picked = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate()
                            dateOfBirth = picked.toString()
                        }
                        showDobPicker = false
                    }
                ) { Text(strings.confirm) }
            },
            dismissButton = {
                TextButton(onClick = { showDobPicker = false }) { Text(strings.cancel) }
            }
        ) {
            DatePicker(state = pickerState)
        }
    }

    if (showWeeklyOffCalendarPicker) {
        val pickerState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showWeeklyOffCalendarPicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        pickerState.selectedDateMillis?.let { millis ->
                            val picked = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate()
                            weeklyOffDay = picked.dayOfWeek.value
                        }
                        showWeeklyOffCalendarPicker = false
                    }
                ) { Text(strings.confirm) }
            },
            dismissButton = {
                TextButton(onClick = { showWeeklyOffCalendarPicker = false }) { Text(strings.cancel) }
            }
        ) {
            DatePicker(state = pickerState)
        }
    }
}
