package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.auth.PinSecurity
import com.example.auth.attemptAutoSignIn
import com.example.auth.onGoogleSignInClicked
import com.example.data.PreferencesManager
import com.example.localization.AppStrings
import com.example.model.AppLanguage
import com.example.model.UserPreferencesState
import com.example.ui.components.HeaderClockBar
import com.example.util.AppShareHelper
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(
    strings: AppStrings,
    preferences: UserPreferencesState,
    preferencesManager: PreferencesManager,
    onAuthenticatedAndUnlocked: (contact: String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    var isGoogleLinked by remember { mutableStateOf(Firebase.auth.currentUser != null) }
    var isGoogleLoading by remember { mutableStateOf(false) }

    var contactInput by remember {
        mutableStateOf(
            preferences.savedLoginContact.ifBlank {
                Firebase.auth.currentUser?.email ?: ""
            }
        )
    }
    var pinInput by remember { mutableStateOf("") }
    var pinVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Forgot PIN OTP Dialog state
    var showOtpDialog by remember { mutableStateOf(false) }
    var generatedOtp by remember { mutableStateOf<String?>(null) }
    var otpChannelLabel by remember { mutableStateOf("") }
    var otpInput by remember { mutableStateOf("") }
    var newPinInput by remember { mutableStateOf("") }
    var otpError by remember { mutableStateOf<String?>(null) }

    val hasExistingPin = preferences.localPinHash.isNotBlank() && preferences.localPinSalt.isNotBlank()

    // Attempt silent Google auto sign-in on cold start
    LaunchedEffect(Unit) {
        if (Firebase.auth.currentUser == null) {
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {
                    isGoogleLinked = true
                    if (contactInput.isBlank()) {
                        contactInput = Firebase.auth.currentUser?.email ?: ""
                    }
                },
                onUnauthenticated = { isGoogleLinked = false },
                scope = scope
            )
        } else {
            isGoogleLinked = true
        }
    }

    fun handleVerifyOrSetPinAndProceed() {
        errorMessage = null
        val cleanPin = pinInput.filter { it.isDigit() }
        if (cleanPin.length != 6) {
            errorMessage = strings.pinLengthError
            return
        }
        if (Firebase.auth.currentUser == null) {
            // Trigger Google Sign-In flow via CredentialManager first so Firestore sync is authenticated
            isGoogleLoading = true
            onGoogleSignInClicked(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {
                    isGoogleLoading = false
                    isGoogleLinked = true
                    val effectiveContact = contactInput.ifBlank { Firebase.auth.currentUser?.email ?: "" }
                    scope.launch {
                        if (!hasExistingPin) {
                            val salt = PinSecurity.generateSalt()
                            val hash = PinSecurity.hashPin(cleanPin, salt)
                            preferencesManager.savePinCredentials(effectiveContact, hash, salt)
                            onAuthenticatedAndUnlocked(effectiveContact)
                        } else if (PinSecurity.verifyPin(cleanPin, preferences.localPinHash, preferences.localPinSalt)) {
                            preferencesManager.setPinVerified(true, effectiveContact)
                            onAuthenticatedAndUnlocked(effectiveContact)
                        } else {
                            errorMessage = strings.pinMismatchError
                        }
                    }
                },
                onAuthError = { msg ->
                    isGoogleLoading = false
                    errorMessage = msg
                },
                scope = scope,
                onAuthCancelled = {
                    isGoogleLoading = false
                    errorMessage = strings.needGoogleSignInNotice
                }
            )
            return
        }

        val effectiveContact = contactInput.ifBlank { Firebase.auth.currentUser?.email ?: "" }
        scope.launch {
            if (!hasExistingPin) {
                val salt = PinSecurity.generateSalt()
                val hash = PinSecurity.hashPin(cleanPin, salt)
                preferencesManager.savePinCredentials(effectiveContact, hash, salt)
                onAuthenticatedAndUnlocked(effectiveContact)
            } else if (PinSecurity.verifyPin(cleanPin, preferences.localPinHash, preferences.localPinSalt)) {
                preferencesManager.setPinVerified(true, effectiveContact)
                onAuthenticatedAndUnlocked(effectiveContact)
            } else {
                errorMessage = strings.pinMismatchError
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) {
        HeaderClockBar(
            strings = strings,
            language = AppLanguage.MARATHI,
            showHomeShare = false,
            onShareAppClick = {}
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 580.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Hero Illustration Card
                Card(
                    shape = MaterialTheme.shapes.large,
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box {
                        Image(
                            painter = painterResource(id = R.drawable.img_bus_diary_hero),
                            contentDescription = strings.appHeaderTitle,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(145.dp)
                        )
                        Surface(
                            color = Color.Black.copy(alpha = 0.55f),
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                                Text(
                                    text = strings.loginTitle,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = strings.loginSubtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFFFE0B2)
                                )
                            }
                        }
                    }
                }

                // Login Form Card
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Google Sign-In Option (Required for Firebase Auth & Cloud Sync)
                        if (isGoogleLinked) {
                            Surface(
                                color = Color(0xFFDDF6E4),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF0F6B36)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = strings.googleLinkedBadge,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = Color(0xFF0F6B36),
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = Firebase.auth.currentUser?.email ?: "",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF14532D)
                                        )
                                    }
                                }
                            }
                        } else {
                            FilledTonalButton(
                                onClick = {
                                    errorMessage = null
                                    isGoogleLoading = true
                                    onGoogleSignInClicked(
                                        context = context,
                                        credentialManager = credentialManager,
                                        onAuthSuccess = {
                                            isGoogleLoading = false
                                            isGoogleLinked = true
                                            if (contactInput.isBlank()) {
                                                contactInput = Firebase.auth.currentUser?.email ?: ""
                                            }
                                        },
                                        onAuthError = { msg ->
                                            isGoogleLoading = false
                                            errorMessage = msg
                                        },
                                        scope = scope,
                                        onAuthCancelled = { isGoogleLoading = false }
                                    )
                                },
                                enabled = !isGoogleLoading,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("google_sign_in_button")
                            ) {
                                if (isGoogleLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                } else {
                                    Icon(Icons.Filled.AccountCircle, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(strings.googleLoginBtn)
                                }
                            }
                        }

                        // Email or Mobile Input
                        OutlinedTextField(
                            value = contactInput,
                            onValueChange = { contactInput = it },
                            label = { Text(strings.emailOrMobileLabel) },
                            placeholder = { Text(strings.emailOrMobileHint) },
                            leadingIcon = { Icon(Icons.Filled.PhoneAndroid, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_contact_input")
                        )

                        // 6-Digit PIN Input
                        OutlinedTextField(
                            value = pinInput,
                            onValueChange = { value ->
                                val digits = value.filter { it.isDigit() }.take(6)
                                pinInput = digits
                            },
                            label = { Text(strings.sixDigitPinLabel) },
                            placeholder = {
                                Text(if (hasExistingPin) strings.enterSixDigitPinHint else strings.setSixDigitPinHint)
                            },
                            leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                            trailingIcon = {
                                IconButton(onClick = { pinVisible = !pinVisible }) {
                                    Icon(
                                        imageVector = if (pinVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                        contentDescription = null
                                    )
                                }
                            },
                            visualTransformation = if (pinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_pin_input")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = {
                                    otpError = null
                                    generatedOtp = null
                                    otpInput = ""
                                    newPinInput = ""
                                    showOtpDialog = true
                                },
                                modifier = Modifier.testTag("forgot_pin_button")
                            ) {
                                Text(strings.forgotPinBtn)
                            }
                        }

                        if (!errorMessage.isNullOrBlank()) {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = errorMessage!!,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }

                        // Horizontal Row with Login Button and Submit Button side by side
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    if (!isGoogleLinked) {
                                        isGoogleLoading = true
                                        onGoogleSignInClicked(
                                            context = context,
                                            credentialManager = credentialManager,
                                            onAuthSuccess = {
                                                isGoogleLoading = false
                                                isGoogleLinked = true
                                                if (contactInput.isBlank()) {
                                                    contactInput = Firebase.auth.currentUser?.email ?: ""
                                                }
                                            },
                                            onAuthError = { msg ->
                                                isGoogleLoading = false
                                                errorMessage = msg
                                            },
                                            scope = scope,
                                            onAuthCancelled = { isGoogleLoading = false }
                                        )
                                    } else {
                                        handleVerifyOrSetPinAndProceed()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("login_button")
                            ) {
                                Text(strings.loginBtn, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { handleVerifyOrSetPinAndProceed() },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("submit_login_button")
                            ) {
                                Text(strings.submitBtn, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showOtpDialog) {
        AlertDialog(
            onDismissRequest = { showOtpDialog = false },
            title = { Text(strings.otpDialogTitle, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilledTonalButton(
                            onClick = {
                                val otp = PinSecurity.generateSixDigitOtp()
                                generatedOtp = otp
                                otpChannelLabel = "Email: ${contactInput.ifBlank { Firebase.auth.currentUser?.email ?: "Email" }}"
                                val targetEmail = contactInput.takeIf { it.contains("@") }
                                    ?: Firebase.auth.currentUser?.email
                                    ?: ""
                                if (targetEmail.isNotBlank()) {
                                    AppShareHelper.openEmail(
                                        context = context,
                                        email = targetEmail,
                                        subject = "Bus Duty Diary OTP: $otp"
                                    )
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Email, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.sendOtpEmail, style = MaterialTheme.typography.labelSmall)
                        }

                        FilledTonalButton(
                            onClick = {
                                val otp = PinSecurity.generateSixDigitOtp()
                                generatedOtp = otp
                                val targetPhone = contactInput.filter { it.isDigit() }.ifBlank { "" }
                                otpChannelLabel = "Mobile: ${targetPhone.ifBlank { "SMS" }}"
                                if (targetPhone.length >= 10) {
                                    AppShareHelper.sendSms(
                                        context = context,
                                        phone = targetPhone,
                                        body = "Bus Duty Diary OTP: $otp"
                                    )
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.PhoneAndroid, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.sendOtpMobile, style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    if (generatedOtp != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "${strings.otpSentBanner} $generatedOtp",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = otpChannelLabel,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = otpInput,
                        onValueChange = { otpInput = it.filter { c -> c.isDigit() }.take(6) },
                        label = { Text(strings.enterOtpLabel) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newPinInput,
                        onValueChange = { newPinInput = it.filter { c -> c.isDigit() }.take(6) },
                        label = { Text(strings.newPinLabel) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (!otpError.isNullOrBlank()) {
                        Text(
                            text = otpError!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (generatedOtp == null || otpInput != generatedOtp) {
                            otpError = "Invalid OTP"
                            return@Button
                        }
                        if (newPinInput.length != 6) {
                            otpError = strings.pinLengthError
                            return@Button
                        }
                        val salt = PinSecurity.generateSalt()
                        val hash = PinSecurity.hashPin(newPinInput, salt)
                        scope.launch {
                            preferencesManager.savePinCredentials(contactInput, hash, salt)
                            pinInput = newPinInput
                            showOtpDialog = false
                        }
                    }
                ) {
                    Text(strings.verifyResetBtn)
                }
            },
            dismissButton = {
                TextButton(onClick = { showOtpDialog = false }) {
                    Text(strings.cancel)
                }
            }
        )
    }
}
