package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.DutyRulesEngine
import com.example.data.ReportCategory
import com.example.localization.AppStrings
import com.example.localization.marathiMonthLabel
import com.example.model.AppLanguage
import com.example.model.DiaryEntry
import com.example.model.EmployeeProfile
import com.example.ui.theme.StatusCOffTakenBg
import com.example.ui.theme.StatusCOffTakenFg
import com.example.ui.theme.StatusDutyBg
import com.example.ui.theme.StatusDutyFg
import com.example.ui.theme.StatusLeaveBg
import com.example.ui.theme.StatusLeaveFg
import com.example.ui.theme.StatusPhTakenBg
import com.example.ui.theme.StatusPhTakenFg
import com.example.ui.theme.StatusWeeklyOffBg
import com.example.ui.theme.StatusWeeklyOffBrokenBg
import com.example.ui.theme.StatusWeeklyOffBrokenFg
import com.example.ui.theme.StatusWeeklyOffFg
import com.example.util.PdfReportGenerator
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun DutyReportScreen(
    strings: AppStrings,
    language: AppLanguage,
    profile: EmployeeProfile?,
    entries: List<DiaryEntry>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val today = remember { LocalDate.now() }
    var isYearly by remember { mutableStateOf(false) }
    var activeMonth by remember { mutableStateOf(YearMonth.from(today)) }
    var activeYear by remember { mutableIntStateOf(today.year) }

    val startDate = if (isYearly) LocalDate.of(activeYear, 1, 1) else activeMonth.atDay(1)
    val endDate = if (isYearly) LocalDate.of(activeYear, 12, 31) else activeMonth.atEndOfMonth()

    val rows = remember(startDate, endDate, today, profile?.weeklyOffDay, entries) {
        DutyRulesEngine.buildReportRows(
            startDate = startDate,
            endDate = endDate,
            today = today,
            weeklyOffDay = profile?.weeklyOffDay ?: 0,
            entries = entries
        )
    }

    val dutyCount = rows.count { it.category == ReportCategory.DUTY }
    val leaveCount = rows.count { it.category == ReportCategory.LEAVE }
    val woCount = rows.count { it.category == ReportCategory.WEEKLY_OFF }
    val brokenWoCount = rows.count { it.category == ReportCategory.BROKEN_WEEKLY_OFF }
    val phCount = rows.count { it.category == ReportCategory.PH_TAKEN }
    val cOffCount = rows.count { it.category == ReportCategory.C_OFF_TAKEN }

    val periodTitle = if (isYearly) {
        "${strings.reportHeading}: $activeYear (Up to $today)"
    } else {
        "${strings.reportHeading}: ${marathiMonthLabel(activeMonth.monthValue, language)} ${activeMonth.year} (Up to $today)"
    }

    val summaryLine =
        "${strings.totalDutiesLabel}: $dutyCount | ${strings.totalLeavesLabel}: $leaveCount | " +
            "${strings.totalWeeklyOffsLabel}: $woCount | ${strings.brokenWeeklyOffsLabel}: $brokenWoCount | " +
            "PH: $phCount | C-Off: $cOffCount"

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = strings.reportHeading,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Surface(
                color = MaterialTheme.colorScheme.secondaryContainer,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = strings.upToTodayNotice,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }

        item {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = !isYearly,
                    onClick = { isYearly = false },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    modifier = Modifier.testTag("report_monthly_tab")
                ) {
                    Text(strings.monthlyTab)
                }
                SegmentedButton(
                    selected = isYearly,
                    onClick = { isYearly = true },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    modifier = Modifier.testTag("report_yearly_tab")
                ) {
                    Text(strings.yearlyTab)
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (isYearly) activeYear -= 1 else activeMonth = activeMonth.minusMonths(1)
                    }
                ) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous")
                }
                Text(
                    text = if (isYearly) "$activeYear" else "${marathiMonthLabel(activeMonth.monthValue, language)} ${activeMonth.year}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = {
                        if (isYearly) {
                            if (activeYear < today.year) activeYear += 1
                        } else {
                            if (activeMonth.isBefore(YearMonth.from(today))) activeMonth = activeMonth.plusMonths(1)
                        }
                    }
                ) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next")
                }
            }
        }

        // Summary KPI Card
        item {
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    ReportKpi(strings.totalDutiesLabel, dutyCount, StatusDutyFg)
                    ReportKpi(strings.totalLeavesLabel, leaveCount, StatusLeaveFg)
                    ReportKpi(strings.totalWeeklyOffsLabel, woCount, StatusWeeklyOffFg)
                    ReportKpi(strings.brokenWeeklyOffsLabel, brokenWoCount, StatusWeeklyOffBrokenFg)
                }
            }
        }

        // PDF Export & Share Options (WhatsApp, Email, Google Drive)
        item {
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val uri = PdfReportGenerator.generateDutyReportPdf(context, periodTitle, profile, rows, summaryLine)
                            PdfReportGenerator.sharePdf(context, uri)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("export_pdf_button")
                    ) {
                        Icon(Icons.Filled.PictureAsPdf, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.exportPdfBtn, fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilledTonalButton(
                            onClick = {
                                val uri = PdfReportGenerator.generateDutyReportPdf(context, periodTitle, profile, rows, summaryLine)
                                PdfReportGenerator.sharePdf(context, uri, targetPackage = "com.whatsapp")
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.shareWhatsappBtn)
                        }
                        FilledTonalButton(
                            onClick = {
                                val uri = PdfReportGenerator.generateDutyReportPdf(context, periodTitle, profile, rows, summaryLine)
                                PdfReportGenerator.sharePdf(context, uri, emailRecipient = profile?.email)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Email, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.shareEmailBtn)
                        }
                        FilledTonalButton(
                            onClick = {
                                val uri = PdfReportGenerator.generateDutyReportPdf(context, periodTitle, profile, rows, summaryLine)
                                PdfReportGenerator.sharePdf(context, uri, targetPackage = "com.google.android.apps.docs")
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.shareDriveBtn)
                        }
                    }
                }
            }
        }

        if (rows.isEmpty()) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = strings.noReportEntries,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(rows, key = { it.dateIso + it.category.name }) { row ->
                val (bg, fg) = when (row.category) {
                    ReportCategory.DUTY -> StatusDutyBg to StatusDutyFg
                    ReportCategory.LEAVE -> StatusLeaveBg to StatusLeaveFg
                    ReportCategory.WEEKLY_OFF -> StatusWeeklyOffBg to StatusWeeklyOffFg
                    ReportCategory.BROKEN_WEEKLY_OFF -> StatusWeeklyOffBrokenBg to StatusWeeklyOffBrokenFg
                    ReportCategory.PH_TAKEN -> StatusPhTakenBg to StatusPhTakenFg
                    ReportCategory.C_OFF_TAKEN -> StatusCOffTakenBg to StatusCOffTakenFg
                }
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = row.dateIso,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = row.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            if (row.subtitle.isNotBlank()) {
                                Text(
                                    text = row.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Surface(color = bg, shape = RoundedCornerShape(8.dp)) {
                            Text(
                                text = row.category.name.replace("_", " "),
                                style = MaterialTheme.typography.labelSmall,
                                color = fg,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun ReportKpi(label: String, count: Int, tint: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = count.toString(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = tint)
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
