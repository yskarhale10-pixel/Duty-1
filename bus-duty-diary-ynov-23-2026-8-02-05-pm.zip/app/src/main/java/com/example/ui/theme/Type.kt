package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppFontChoice
import com.example.model.FontSizeScale

val NotoSansDevanagariFontFamily = FontFamily(
    Font(R.font.noto_sans_devanagari, FontWeight.Normal)
)

val PoppinsFontFamily = FontFamily(
    Font(R.font.poppins, FontWeight.Normal)
)

val TiroMarathiFontFamily = FontFamily(
    Font(R.font.tiro_devanagari_marathi, FontWeight.Normal)
)

val JetBrainsMonoFontFamily = FontFamily(
    Font(R.font.jetbrains_mono, FontWeight.Normal)
)

fun resolveFontFamily(choice: AppFontChoice): FontFamily = when (choice) {
    AppFontChoice.NOTO_DEVANAGARI -> NotoSansDevanagariFontFamily
    AppFontChoice.POPPINS -> PoppinsFontFamily
    AppFontChoice.TIRO_MARATHI -> TiroMarathiFontFamily
    AppFontChoice.SYSTEM_DEFAULT -> FontFamily.SansSerif
}

fun buildDiaryTypography(
    fontChoice: AppFontChoice = AppFontChoice.NOTO_DEVANAGARI,
    sizeScale: FontSizeScale = FontSizeScale.MEDIUM
): Typography {
    val family = resolveFontFamily(fontChoice)
    val m = sizeScale.multiplier
    return Typography(
        displaySmall = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Bold,
            fontSize = (28f * m).sp,
            lineHeight = (34f * m).sp
        ),
        headlineMedium = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Bold,
            fontSize = (22f * m).sp,
            lineHeight = (28f * m).sp
        ),
        headlineSmall = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Bold,
            fontSize = (19f * m).sp,
            lineHeight = (25f * m).sp
        ),
        titleLarge = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.SemiBold,
            fontSize = (18f * m).sp,
            lineHeight = (24f * m).sp
        ),
        titleMedium = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.SemiBold,
            fontSize = (15.5f * m).sp,
            lineHeight = (21f * m).sp
        ),
        titleSmall = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Medium,
            fontSize = (13.5f * m).sp,
            lineHeight = (19f * m).sp
        ),
        bodyLarge = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Normal,
            fontSize = (15f * m).sp,
            lineHeight = (22f * m).sp
        ),
        bodyMedium = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Normal,
            fontSize = (13.5f * m).sp,
            lineHeight = (19f * m).sp
        ),
        bodySmall = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Normal,
            fontSize = (12f * m).sp,
            lineHeight = (16f * m).sp
        ),
        labelLarge = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.SemiBold,
            fontSize = (13.5f * m).sp,
            lineHeight = (18f * m).sp
        ),
        labelMedium = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Medium,
            fontSize = (11.5f * m).sp,
            lineHeight = (15f * m).sp
        ),
        labelSmall = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Medium,
            fontSize = (10.5f * m).sp,
            lineHeight = (14f * m).sp
        )
    )
}
