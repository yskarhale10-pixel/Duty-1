package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.AppFontChoice
import com.example.model.AppThemeStyle
import com.example.model.FontSizeScale

private val DiaryShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp)
)

private fun lightSchemeFor(style: AppThemeStyle): ColorScheme = when (style) {
    AppThemeStyle.CRIMSON_GOLD -> lightColorScheme(
        primary = CrimsonPrimary,
        onPrimary = CrimsonOnPrimary,
        primaryContainer = CrimsonPrimaryContainer,
        onPrimaryContainer = CrimsonOnPrimaryContainer,
        secondary = GoldSecondary,
        onSecondary = GoldOnSecondary,
        secondaryContainer = GoldSecondaryContainer,
        onSecondaryContainer = GoldOnSecondaryContainer,
        background = WarmIvoryBackground,
        surface = WarmSurface,
        surfaceVariant = WarmSurfaceVariant,
        onBackground = Color(0xFF1F1A1A),
        onSurface = Color(0xFF1F1A1A)
    )
    AppThemeStyle.SAHYADRI_EMERALD -> lightColorScheme(
        primary = EmeraldPrimary,
        onPrimary = Color.White,
        primaryContainer = EmeraldPrimaryContainer,
        onPrimaryContainer = EmeraldOnPrimaryContainer,
        secondary = EmeraldSecondary,
        onSecondary = Color.White,
        secondaryContainer = EmeraldSecondaryContainer,
        onSecondaryContainer = Color(0xFF332000),
        background = Color(0xFFF6FBF6),
        surface = Color(0xFFFBFDFB),
        surfaceVariant = Color(0xFFE3EFE4),
        onBackground = Color(0xFF161D17),
        onSurface = Color(0xFF161D17)
    )
    AppThemeStyle.KONKAN_OCEAN -> lightColorScheme(
        primary = OceanPrimary,
        onPrimary = Color.White,
        primaryContainer = OceanPrimaryContainer,
        onPrimaryContainer = OceanOnPrimaryContainer,
        secondary = OceanSecondary,
        onSecondary = Color.White,
        secondaryContainer = OceanSecondaryContainer,
        onSecondaryContainer = Color(0xFF002024),
        background = Color(0xFFF5F9FF),
        surface = Color(0xFFFAFCFF),
        surfaceVariant = Color(0xFFE1EAF6),
        onBackground = Color(0xFF161B22),
        onSurface = Color(0xFF161B22)
    )
    AppThemeStyle.ROYAL_SAFFRON -> lightColorScheme(
        primary = SaffronPrimary,
        onPrimary = Color.White,
        primaryContainer = SaffronPrimaryContainer,
        onPrimaryContainer = SaffronOnPrimaryContainer,
        secondary = SaffronSecondary,
        onSecondary = Color.White,
        secondaryContainer = SaffronSecondaryContainer,
        onSecondaryContainer = Color(0xFF2B0042),
        background = Color(0xFFFFFAF5),
        surface = Color(0xFFFFFDF9),
        surfaceVariant = Color(0xFFF7E6DD),
        onBackground = Color(0xFF211A17),
        onSurface = Color(0xFF211A17)
    )
}

private fun darkSchemeFor(style: AppThemeStyle): ColorScheme = when (style) {
    AppThemeStyle.CRIMSON_GOLD -> darkColorScheme(
        primary = Color(0xFFFFB4AB),
        onPrimary = Color(0xFF690005),
        primaryContainer = Color(0xFF93000A),
        onPrimaryContainer = Color(0xFFFFDAD6),
        secondary = Color(0xFFFFB74D),
        onSecondary = Color(0xFF452B00),
        secondaryContainer = Color(0xFF633F00),
        onSecondaryContainer = Color(0xFFFFDDB3),
        background = Color(0xFF161111),
        surface = Color(0xFF1F1818),
        surfaceVariant = Color(0xFF332626)
    )
    AppThemeStyle.SAHYADRI_EMERALD -> darkColorScheme(
        primary = Color(0xFF81C784),
        onPrimary = Color(0xFF00390F),
        primaryContainer = Color(0xFF00531A),
        onPrimaryContainer = Color(0xFFC8E6C9),
        secondary = Color(0xFFFFD54F),
        onSecondary = Color(0xFF3A2D00),
        background = Color(0xFF101611),
        surface = Color(0xFF182019),
        surfaceVariant = Color(0xFF273429)
    )
    AppThemeStyle.KONKAN_OCEAN -> darkColorScheme(
        primary = Color(0xFF90CAF9),
        onPrimary = Color(0xFF003063),
        primaryContainer = Color(0xFF00468C),
        onPrimaryContainer = Color(0xFFD3E3FD),
        secondary = Color(0xFF80DEEA),
        onSecondary = Color(0xFF00363C),
        background = Color(0xFF0F141B),
        surface = Color(0xFF171E28),
        surfaceVariant = Color(0xFF25303F)
    )
    AppThemeStyle.ROYAL_SAFFRON -> darkColorScheme(
        primary = Color(0xFFFFAB91),
        onPrimary = Color(0xFF5E1700),
        primaryContainer = Color(0xFF872600),
        onPrimaryContainer = Color(0xFFFFDBCF),
        secondary = Color(0xFFCE93D8),
        onSecondary = Color(0xFF420058),
        background = Color(0xFF181210),
        surface = Color(0xFF221A17),
        surfaceVariant = Color(0xFF362823)
    )
}

@Composable
fun BusDutyDiaryTheme(
    themeStyle: AppThemeStyle = AppThemeStyle.CRIMSON_GOLD,
    darkTheme: Boolean = isSystemInDarkTheme(),
    fontChoice: AppFontChoice = AppFontChoice.NOTO_DEVANAGARI,
    fontScale: FontSizeScale = FontSizeScale.MEDIUM,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) darkSchemeFor(themeStyle) else lightSchemeFor(themeStyle)
    MaterialTheme(
        colorScheme = colorScheme,
        typography = buildDiaryTypography(fontChoice, fontScale),
        shapes = DiaryShapes,
        content = content
    )
}
