package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- MSRTC Crimson & Gold Palette (Default) ---
val CrimsonPrimary = Color(0xFFB71C1C)
val CrimsonOnPrimary = Color(0xFFFFFFFF)
val CrimsonPrimaryContainer = Color(0xFFFFDAD6)
val CrimsonOnPrimaryContainer = Color(0xFF410002)
val GoldSecondary = Color(0xFFE65100)
val GoldOnSecondary = Color(0xFFFFFFFF)
val GoldSecondaryContainer = Color(0xFFFFE0B2)
val GoldOnSecondaryContainer = Color(0xFF3E1800)
val WarmIvoryBackground = Color(0xFFFFFBF7)
val WarmSurface = Color(0xFFFFF8F2)
val WarmSurfaceVariant = Color(0xFFF5E6E1)

// --- Sahyadri Emerald Palette ---
val EmeraldPrimary = Color(0xFF1B5E20)
val EmeraldPrimaryContainer = Color(0xFFC8E6C9)
val EmeraldOnPrimaryContainer = Color(0xFF002106)
val EmeraldSecondary = Color(0xFFF57F17)
val EmeraldSecondaryContainer = Color(0xFFFFF3C4)

// --- Konkan Ocean Palette ---
val OceanPrimary = Color(0xFF0D47A1)
val OceanPrimaryContainer = Color(0xFFD3E3FD)
val OceanOnPrimaryContainer = Color(0xFF001C3B)
val OceanSecondary = Color(0xFF00838F)
val OceanSecondaryContainer = Color(0xFFB2EBF2)

// --- Royal Saffron Palette ---
val SaffronPrimary = Color(0xFFD84315)
val SaffronPrimaryContainer = Color(0xFFFFDBCF)
val SaffronOnPrimaryContainer = Color(0xFF3E0F00)
val SaffronSecondary = Color(0xFF6A1B9A)
val SaffronSecondaryContainer = Color(0xFFF3E5F5)

// --- Semantic Calendar & Duty Status Colors ---
val StatusDutyBg = Color(0xFFDDF6E4)
val StatusDutyFg = Color(0xFF0F6B36)
val StatusLeaveBg = Color(0xFFFFE0E3)
val StatusLeaveFg = Color(0xFFB71C1C)
val StatusWeeklyOffBg = Color(0xFFE0EAFF)
val StatusWeeklyOffFg = Color(0xFF1D4ED8)
val StatusWeeklyOffBrokenBg = Color(0xFFFFE4CC)
val StatusWeeklyOffBrokenFg = Color(0xFFC2410C)
val StatusPublicHolidayBg = Color(0xFFFFF4CC)
val StatusPublicHolidayFg = Color(0xFF9A6700)
val StatusPhTakenBg = Color(0xFFD1F5F0)
val StatusPhTakenFg = Color(0xFF0F766E)
val StatusCOffTakenBg = Color(0xFFF0E4FF)
val StatusCOffTakenFg = Color(0xFF6D28D9)
