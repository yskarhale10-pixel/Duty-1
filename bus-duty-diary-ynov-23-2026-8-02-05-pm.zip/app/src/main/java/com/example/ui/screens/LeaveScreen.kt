package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.DutyRulesEngine
import com.example.data.ReportCategory
import com.example.localization.AppStrings
import com.example.model.AppLanguage
import com.example.model.DiaryEntry
import com.example.model.EmployeeProfile
import com.example.model.EntryType
import com.example.model.LeaveCredit
import com.example.ui.theme.StatusCOffTakenBg
import com.example.ui.theme.StatusCOffTakenFg
import com.example.ui.theme.StatusLeaveBg
import com.example.ui.theme.StatusLeaveFg
import com.example.ui.theme.StatusPhTakenBg
import com.example.ui.theme.StatusPhTakenFg
import com.example.ui.theme.StatusWeeklyOffBrokenBg
import com.example.ui.theme.StatusWeeklyOffBrokenFg
import java.time.LocalDate

@Composable
fun LeaveScreen(
    strings: AppStrings,
    language: AppLanguage,
    profile: EmployeeProfile?,
    entries: List<DiaryEntry>,
    credits: List<LeaveCredit>,
    modifier: Modifier = Modifier
) {
    val today = remember { LocalDate.now() }
    val weeklyOffDay = profile?.weeklyOffDay ?: 0
    val balances = remember(credits, today) { DutyRulesEngine.computeBalances(credits, today) }

    val leaveEntries = remember(entries) {
        entries.filter { it.entryTypeEnum() == EntryType.LEAVE }.sortedByDescending { it.dateIso }
    }

    // Broken Weekly Offs across recorded span (counted as Leave)
    val brokenWeeklyOffDates = remember(entries, weeklyOffDay) {
        if (weeklyOffDay !in 1..7 || entries.isEmpty()) {
            emptyList()
        } else {
            val minDate = entries.mapNotNull { DutyRulesEngine.parseDateOrNull(it.dateIso) }.minOrNull() ?: today
            val maxDate = entries.mapNotNull { DutyRulesEngine.parseDateOrNull(it.dateIso) }.maxOrNull() ?: today
            DutyRulesEngine.buildReportRows(minDate, maxDate, maxDate, weeklyOffDay, entries)
                .filter { it.category == ReportCategory.BROKEN_WEEKLY_OFF }
        }
    }

    val phTakenEntries = remember(entries) {
        entries.filter { it.entryTypeEnum() == EntryType.PH }.sortedByDescending { it.dateIso }
    }

    val cOffTakenEntries = remember(entries) {
        entries.filter { it.entryTypeEnum() == EntryType.C_OFF }.sortedByDescending { it.dateIso }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = strings.leaveSummaryHeading,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }

        // PH Balance Card (Taken & Remaining)
        item {
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = StatusPhTakenBg.copy(alpha = 0.65f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.EventAvailable, contentDescription = null, tint = StatusPhTakenFg)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = strings.phBalanceTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = StatusPhTakenFg
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricBox(strings.takenPhLabel, phTakenEntries.size.toString(), StatusPhTakenFg)
                        MetricBox(strings.remainingPhLabel, balances.remainingPh.size.toString(), Color(0xFF0F6B36))
                        MetricBox(strings.expiredPhLabel, balances.expiredPh.size.toString(), StatusWeeklyOffBrokenFg)
                    }
                    if (balances.remainingPh.isNotEmpty()) {
                        balances.remainingPh.forEach { credit ->
                            Text(
                                text = "• ${credit.sourceTitle} (${credit.sourceDate} -> ${credit.expiresAtDate})",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF134E4A)
                            )
                        }
                    }
                }
            }
        }

        // C-Off Balance Card (Taken & Remaining)
        item {
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = StatusCOffTakenBg.copy(alpha = 0.7f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.EventAvailable, contentDescription = null, tint = StatusCOffTakenFg)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = strings.cOffBalanceTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = StatusCOffTakenFg
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        MetricBox(strings.takenCOffLabel, cOffTakenEntries.size.toString(), StatusCOffTakenFg)
                        MetricBox(strings.remainingCOffLabel, balances.remainingCOff.size.toString(), Color(0xFF0F6B36))
                    }
                    if (balances.remainingCOff.isNotEmpty()) {
                        balances.remainingCOff.forEach { credit ->
                            Text(
                                text = "• ${credit.sourceTitle} (${credit.sourceDate})",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF4C1D95)
                            )
                        }
                    }
                }
            }
        }

        // Weekly Off Break Explanation Banner
        if (brokenWeeklyOffDates.isNotEmpty()) {
            item {
                Surface(
                    color = StatusWeeklyOffBrokenBg,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = StatusWeeklyOffBrokenFg)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = strings.brokenWoAsLeaveNote,
                            style = MaterialTheme.typography.bodySmall,
                            color = StatusWeeklyOffBrokenFg,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // All Taken Leaves Section
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                Icon(Icons.Filled.EventBusy, contentDescription = null, tint = StatusLeaveFg)
                Spacer(Modifier.width(6.dp))
                Text(
                    text = "${strings.takenLeavesListTitle} (${leaveEntries.size + brokenWeeklyOffDates.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (leaveEntries.isEmpty() && brokenWeeklyOffDates.isEmpty()) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = strings.noLeavesRecorded,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(leaveEntries, key = { it.dateIso }) { entry ->
                val lt = entry.leaveTypeEnum()
                val ltLabel = when (language) {
                    AppLanguage.MARATHI -> lt?.labelMr ?: entry.leaveType
                    AppLanguage.HINDI -> lt?.labelHi ?: entry.leaveType
                    AppLanguage.ENGLISH -> lt?.labelEn ?: entry.leaveType
                }
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = entry.dateIso,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = ltLabel,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = StatusLeaveFg
                            )
                            if (entry.leaveReason.isNotBlank()) {
                                Text(
                                    text = entry.leaveReason,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                        Surface(color = StatusLeaveBg, shape = RoundedCornerShape(8.dp)) {
                            Text(
                                text = lt?.code ?: "LEAVE",
                                style = MaterialTheme.typography.labelSmall,
                                color = StatusLeaveFg,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            items(brokenWeeklyOffDates, key = { "broken_${it.dateIso}" }) { row ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = StatusWeeklyOffBrokenBg.copy(alpha = 0.55f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = row.dateIso, style = MaterialTheme.typography.labelMedium)
                            Text(
                                text = row.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = StatusWeeklyOffBrokenFg
                            )
                            Text(text = row.subtitle, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun MetricBox(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = color)
        Text(text = label, style = MaterialTheme.typography.labelSmall)
    }
}
