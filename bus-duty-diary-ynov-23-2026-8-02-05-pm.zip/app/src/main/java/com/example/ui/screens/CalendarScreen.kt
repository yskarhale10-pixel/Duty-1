package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DutyRulesEngine
import com.example.data.PublicHolidaysData
import com.example.data.PublicHolidaysData.localizedName
import com.example.localization.AppStrings
import com.example.localization.marathiMonthLabel
import com.example.localization.marathiSeasonLabel
import com.example.localization.shortDayLabel
import com.example.model.AppLanguage
import com.example.model.Designation
import com.example.model.DiaryEntry
import com.example.model.DutyRole
import com.example.model.EmployeeProfile
import com.example.model.EntryType
import com.example.model.LeaveCredit
import com.example.model.LeaveType
import com.example.ui.theme.StatusCOffTakenBg
import com.example.ui.theme.StatusCOffTakenFg
import com.example.ui.theme.StatusDutyBg
import com.example.ui.theme.StatusDutyFg
import com.example.ui.theme.StatusLeaveBg
import com.example.ui.theme.StatusLeaveFg
import com.example.ui.theme.StatusPhTakenBg
import com.example.ui.theme.StatusPhTakenFg
import com.example.ui.theme.StatusPublicHolidayBg
import com.example.ui.theme.StatusPublicHolidayFg
import com.example.ui.theme.StatusWeeklyOffBg
import com.example.ui.theme.StatusWeeklyOffBrokenBg
import com.example.ui.theme.StatusWeeklyOffBrokenFg
import com.example.ui.theme.StatusWeeklyOffFg
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CalendarScreen(
    strings: AppStrings,
    language: AppLanguage,
    currentUserId: String,
    profile: EmployeeProfile?,
    entries: List<DiaryEntry>,
    credits: List<LeaveCredit>,
    onSaveEntry: (DiaryEntry, DiaryEntry?) -> Unit,
    onDeleteEntry: (DiaryEntry) -> Unit,
    onDepositPhCredit: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val today = remember { LocalDate.now() }
    var isYearlyView by remember { mutableStateOf(false) }
    var activeMonth by remember { mutableStateOf(YearMonth.from(today)) }
    var activeYear by remember { mutableIntStateOf(today.year) }

    var selectedDateForEntry by remember { mutableStateOf<LocalDate?>(null) }
    var showDepositPhDialog by remember { mutableStateOf(false) }

    val entriesByDate = remember(entries) { entries.associateBy { it.dateIso } }
    val weeklyOffDay = profile?.weeklyOffDay ?: 0
    val balances = remember(credits, today) { DutyRulesEngine.computeBalances(credits, today) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Monthly / Yearly toggle + Deposit PH button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.weight(1f)) {
                SegmentedButton(
                    selected = !isYearlyView,
                    onClick = { isYearlyView = false },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    modifier = Modifier.testTag("calendar_monthly_tab")
                ) {
                    Text(strings.monthlyTab, maxLines = 1, fontSize = 11.5.sp)
                }
                SegmentedButton(
                    selected = isYearlyView,
                    onClick = { isYearlyView = true },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    modifier = Modifier.testTag("calendar_yearly_tab")
                ) {
                    Text(strings.yearlyTab, maxLines = 1, fontSize = 11.5.sp)
                }
            }

            FilledTonalButton(
                onClick = { showDepositPhDialog = true },
                modifier = Modifier.testTag("deposit_ph_button")
            ) {
                Icon(Icons.Filled.AddCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(strings.depositPhBtn, maxLines = 1, fontSize = 11.5.sp)
            }
        }

        // PH & C-Off Balance Strip
        Card(
            shape = MaterialTheme.shapes.medium,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                BalanceStatPill(strings.remainingPhLabel, balances.remainingPh.size.toString(), StatusPhTakenFg)
                BalanceStatPill(strings.usedPhLabel, balances.usedPh.size.toString(), MaterialTheme.colorScheme.primary)
                BalanceStatPill(strings.expiredPhLabel, balances.expiredPh.size.toString(), StatusWeeklyOffBrokenFg)
                BalanceStatPill(strings.remainingCOffLabel, balances.remainingCOff.size.toString(), StatusCOffTakenFg)
                BalanceStatPill(strings.usedCOffLabel, balances.usedCOff.size.toString(), MaterialTheme.colorScheme.secondary)
            }
        }

        if (!isYearlyView) {
            // --- MONTHLY VIEW ---
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Month navigation header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { activeMonth = activeMonth.minusMonths(1) }) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Prev month")
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${marathiMonthLabel(activeMonth.monthValue, language)} ${activeMonth.year}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = marathiSeasonLabel(activeMonth.monthValue),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { activeMonth = activeMonth.plusMonths(1) }) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next month")
                        }
                    }

                    Spacer(Modifier.height(6.dp))

                    // Weekday headers (Mon..Sun)
                    Row(modifier = Modifier.fillMaxWidth()) {
                        DayOfWeek.entries.forEach { day ->
                            val isWoDay = day.value == weeklyOffDay
                            Text(
                                text = shortDayLabel(day, language),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isWoDay) StatusWeeklyOffFg else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(Modifier.height(6.dp))

                    val firstDayOfMonth = activeMonth.atDay(1)
                    val leadingEmpty = firstDayOfMonth.dayOfWeek.value - 1 // Mon=0 .. Sun=6
                    val totalDays = activeMonth.lengthOfMonth()
                    val totalCells = ((leadingEmpty + totalDays + 6) / 7) * 7

                    for (rowStart in 0 until totalCells step 7) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            for (col in 0 until 7) {
                                val cellIndex = rowStart + col
                                val dayNum = cellIndex - leadingEmpty + 1
                                if (dayNum in 1..totalDays) {
                                    val date = activeMonth.atDay(dayNum)
                                    val iso = date.toString()
                                    val entry = entriesByDate[iso]
                                    val holiday = PublicHolidaysData.getHoliday(iso)
                                    val isWo = DutyRulesEngine.isWeeklyOff(date, weeklyOffDay)
                                    val isWoBroken = DutyRulesEngine.isWeeklyOffBroken(date, weeklyOffDay, entriesByDate)
                                    val isToday = date == today

                                    val (cellBg, cellFg, tagText) = when {
                                        entry?.entryTypeEnum() == EntryType.DUTY -> Triple(StatusDutyBg, StatusDutyFg, "D")
                                        entry?.entryTypeEnum() == EntryType.LEAVE -> Triple(StatusLeaveBg, StatusLeaveFg, entry.leaveTypeEnum()?.code ?: "L")
                                        entry?.entryTypeEnum() == EntryType.PH -> Triple(StatusPhTakenBg, StatusPhTakenFg, "PH")
                                        entry?.entryTypeEnum() == EntryType.C_OFF -> Triple(StatusCOffTakenBg, StatusCOffTakenFg, "CO")
                                        isWoBroken -> Triple(StatusWeeklyOffBrokenBg, StatusWeeklyOffBrokenFg, "WO!")
                                        isWo -> Triple(StatusWeeklyOffBg, StatusWeeklyOffFg, "WO")
                                        holiday != null -> Triple(StatusPublicHolidayBg, StatusPublicHolidayFg, "सुट्टी")
                                        else -> Triple(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.38f), MaterialTheme.colorScheme.onSurface, "")
                                    }

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(0.92f)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(cellBg)
                                            .then(
                                                if (isToday) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp))
                                                else if (holiday != null) Modifier.border(1.dp, StatusPublicHolidayFg.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                                else Modifier
                                            )
                                            .clickable { selectedDateForEntry = date }
                                            .padding(2.dp)
                                            .testTag("calendar_day_$iso"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Text(
                                                text = dayNum.toString(),
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = cellFg
                                            )
                                            if (tagText.isNotBlank()) {
                                                Text(
                                                    text = tagText,
                                                    fontSize = 8.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = cellFg,
                                                    maxLines = 1
                                                )
                                            }
                                            if (holiday != null && tagText != "सुट्टी") {
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(StatusPublicHolidayFg)
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    // Color Legend
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        LegendChip(strings.dutyLegend, StatusDutyBg, StatusDutyFg)
                        LegendChip(strings.leaveLegend, StatusLeaveBg, StatusLeaveFg)
                        LegendChip(strings.weeklyOffLegend, StatusWeeklyOffBg, StatusWeeklyOffFg)
                        LegendChip(strings.weeklyOffBrokenLegend, StatusWeeklyOffBrokenBg, StatusWeeklyOffBrokenFg)
                        LegendChip(strings.phLegend, StatusPublicHolidayBg, StatusPublicHolidayFg)
                        LegendChip(strings.phTakenLegend, StatusPhTakenBg, StatusPhTakenFg)
                        LegendChip(strings.cOffTakenLegend, StatusCOffTakenBg, StatusCOffTakenFg)
                    }
                }
            }

            // Month Public Holidays Card
            val monthHolidays = remember(activeMonth) {
                PublicHolidaysData.holidaysForMonth(activeMonth.year, activeMonth.monthValue)
            }
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Celebration, contentDescription = null, tint = StatusPublicHolidayFg)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "${strings.publicHolidaysSection} — ${marathiMonthLabel(activeMonth.monthValue, language)}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (monthHolidays.isEmpty()) {
                        Text(
                            text = "-",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        monthHolidays.forEach { holiday ->
                            Surface(
                                color = StatusPublicHolidayBg,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        DutyRulesEngine.parseDateOrNull(holiday.dateIso)?.let {
                                            selectedDateForEntry = it
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = holiday.localizedName(language),
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = StatusPublicHolidayFg
                                        )
                                        Text(
                                            text = "${holiday.dateIso} • ${holiday.marathiMonthNote}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF5D4037)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // --- YEARLY VIEW ---
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { activeYear -= 1 }) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Prev year")
                        }
                        Text(
                            text = "$activeYear",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        IconButton(onClick = { activeYear += 1 }) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next year")
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    for (row in 0 until 4) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            for (col in 0 until 3) {
                                val m = row * 3 + col + 1
                                val ym = YearMonth.of(activeYear, m)
                                val prefix = "%04d-%02d-".format(activeYear, m)
                                val dutyCount = entries.count { it.dateIso.startsWith(prefix) && it.entryTypeEnum() == EntryType.DUTY }
                                val leaveCount = entries.count { it.dateIso.startsWith(prefix) && it.entryTypeEnum() == EntryType.LEAVE }
                                val holidayCount = PublicHolidaysData.holidaysForMonth(activeYear, m).size

                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            activeMonth = ym
                                            isYearlyView = false
                                        }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = marathiMonthLabel(m, language),
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(Modifier.height(4.dp))
                                        Text("D:$dutyCount  L:$leaveCount", style = MaterialTheme.typography.labelSmall, color = StatusDutyFg)
                                        Text("PH:$holidayCount", style = MaterialTheme.typography.labelSmall, color = StatusPublicHolidayFg)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "${strings.publicHolidaysSection} ($activeYear)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(6.dp))
                    PublicHolidaysData.holidaysForYear(activeYear).forEach { holiday ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = holiday.localizedName(language),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "${holiday.dateIso} (${holiday.marathiMonthNote})",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }

    // --- DATE ENTRY DIALOG (Duty / Leave / PH / C-Off) ---
    val clickedDate = selectedDateForEntry
    if (clickedDate != null) {
        DateEntryDialog(
            date = clickedDate,
            strings = strings,
            language = language,
            currentUserId = currentUserId,
            profile = profile,
            existingEntry = entriesByDate[clickedDate.toString()],
            credits = credits,
            weeklyOffDay = weeklyOffDay,
            onDismiss = { selectedDateForEntry = null },
            onSave = { newEntry, oldEntry ->
                onSaveEntry(newEntry, oldEntry)
                selectedDateForEntry = null
            },
            onDelete = { oldEntry ->
                onDeleteEntry(oldEntry)
                selectedDateForEntry = null
            }
        )
    }

    // --- DEPOSIT PH FROM CALENDAR DIALOG ---
    if (showDepositPhDialog) {
        val depositedDates = remember(credits) { credits.filter { it.creditType == "PH" }.map { it.sourceDate }.toSet() }
        val yearHolidays = remember(activeYear) { PublicHolidaysData.holidaysForYear(activeYear) }

        AlertDialog(
            onDismissRequest = { showDepositPhDialog = false },
            title = { Text(strings.depositPhTitle, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(strings.depositPhSubtitle, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(modifier = Modifier.height(300.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(yearHolidays) { holiday ->
                            val already = depositedDates.contains(holiday.dateIso)
                            Surface(
                                color = if (already) StatusPhTakenBg else StatusPublicHolidayBg,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = holiday.localizedName(language),
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${holiday.dateIso} • ${holiday.marathiMonthNote}",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                    if (already) {
                                        Text(
                                            text = strings.alreadyDepositedLabel,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = StatusPhTakenFg,
                                            fontWeight = FontWeight.Bold
                                        )
                                    } else {
                                        TextButton(
                                            onClick = {
                                                onDepositPhCredit(holiday.dateIso, holiday.localizedName(language))
                                            }
                                        ) {
                                            Text(strings.depositNowBtn, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDepositPhDialog = false }) {
                    Text(strings.close)
                }
            }
        )
    }
}

@Composable
private fun BalanceStatPill(label: String, value: String, tint: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = tint)
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun LegendChip(label: String, bg: Color, fg: Color) {
    Surface(color = bg, shape = RoundedCornerShape(6.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DateEntryDialog(
    date: LocalDate,
    strings: AppStrings,
    language: AppLanguage,
    currentUserId: String,
    profile: EmployeeProfile?,
    existingEntry: DiaryEntry?,
    credits: List<LeaveCredit>,
    weeklyOffDay: Int,
    onDismiss: () -> Unit,
    onSave: (DiaryEntry, DiaryEntry?) -> Unit,
    onDelete: (DiaryEntry) -> Unit
) {
    val dateIso = date.toString()
    val holiday = remember(dateIso) { PublicHolidaysData.getHoliday(dateIso) }
    val isWeeklyOff = DutyRulesEngine.isWeeklyOff(date, weeklyOffDay)

    var selectedType by remember { mutableStateOf(existingEntry?.entryTypeEnum() ?: EntryType.DUTY) }

    // Duty fields
    var dutyNumber by remember { mutableStateOf(existingEntry?.dutyNumber ?: "") }
    var dutyName by remember { mutableStateOf(existingEntry?.dutyName ?: "") }
    var busNumber by remember { mutableStateOf(existingEntry?.busNumber ?: "") }
    var coworkerName by remember { mutableStateOf(existingEntry?.coworkerName ?: "") }
    var coworkerBadge by remember { mutableStateOf(existingEntry?.coworkerBadge ?: "") }
    var startTime by remember { mutableStateOf(existingEntry?.startTime ?: "06:00 AM") }
    var endTime by remember { mutableStateOf(existingEntry?.endTime ?: "02:30 PM") }
    var performedRole by remember { mutableStateOf(existingEntry?.performedRoleEnum() ?: DutyRole.DRIVER) }

    // Leave fields
    var leaveType by remember { mutableStateOf(existingEntry?.leaveTypeEnum() ?: LeaveType.CL) }
    var leaveReason by remember { mutableStateOf(existingEntry?.leaveReason ?: "") }

    // Valid PH & C-Off credits for this target date
    val validPhCredits = remember(credits, dateIso, weeklyOffDay) {
        credits.filter {
            (it.id == existingEntry?.creditId) || DutyRulesEngine.isPhCreditValidForDate(it, date, weeklyOffDay)
        }
    }
    val validCOffCredits = remember(credits, dateIso, weeklyOffDay) {
        credits.filter {
            (it.id == existingEntry?.creditId) || DutyRulesEngine.isCOffCreditValidForDate(it, date, weeklyOffDay)
        }
    }
    var selectedCreditId by remember { mutableStateOf(existingEntry?.creditId ?: "") }

    val isDriverCumConductor = profile?.designationEnum() == Designation.DRIVER_CUM_CONDUCTOR

    val canSave = when (selectedType) {
        EntryType.DUTY -> dutyNumber.isNotBlank() || dutyName.isNotBlank() || busNumber.isNotBlank()
        EntryType.LEAVE -> true
        EntryType.PH -> selectedCreditId.isNotBlank() && validPhCredits.any { it.id == selectedCreditId }
        EntryType.C_OFF -> selectedCreditId.isNotBlank() && validCOffCredits.any { it.id == selectedCreditId }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("${strings.dateEntryTitle} ($dateIso)", fontWeight = FontWeight.Bold)
                if (holiday != null) {
                    Text(
                        text = "${strings.phLegend}: ${holiday.localizedName(language)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusPublicHolidayFg
                    )
                }
                if (isWeeklyOff) {
                    Text(
                        text = strings.weeklyOffLegend,
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusWeeklyOffFg
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // 4 Type Selection Buttons: Duty | Leave | PH | C-Off
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    EntryType.entries.forEach { type ->
                        val label = when (language) {
                            AppLanguage.MARATHI -> type.labelMr
                            AppLanguage.HINDI -> type.labelHi
                            AppLanguage.ENGLISH -> type.labelEn
                        }
                        FilterChip(
                            selected = selectedType == type,
                            onClick = {
                                selectedType = type
                                if (type == EntryType.PH) {
                                    selectedCreditId = validPhCredits.firstOrNull()?.id ?: ""
                                } else if (type == EntryType.C_OFF) {
                                    selectedCreditId = validCOffCredits.firstOrNull()?.id ?: ""
                                }
                            },
                            label = { Text(label, fontWeight = FontWeight.Bold) },
                            modifier = Modifier.testTag("entry_type_${type.name}")
                        )
                    }
                }

                when (selectedType) {
                    EntryType.DUTY -> {
                        if (isDriverCumConductor) {
                            Text(strings.todayRoleLabel, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                DutyRole.entries.forEach { r ->
                                    val rLabel = when (language) {
                                        AppLanguage.MARATHI -> r.labelMr
                                        AppLanguage.HINDI -> r.labelHi
                                        AppLanguage.ENGLISH -> r.labelEn
                                    }
                                    FilterChip(
                                        selected = performedRole == r,
                                        onClick = { performedRole = r },
                                        label = { Text(rLabel) }
                                    )
                                }
                            }
                        }
                        OutlinedTextField(
                            value = dutyNumber,
                            onValueChange = { dutyNumber = it },
                            label = { Text(strings.dutyNumberLabel) },
                            leadingIcon = { Icon(Icons.Filled.DirectionsBus, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = dutyName,
                            onValueChange = { dutyName = it },
                            label = { Text(strings.dutyNameLabel) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = busNumber,
                            onValueChange = { busNumber = it },
                            label = { Text(strings.busNumberLabel) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = coworkerName,
                            onValueChange = { coworkerName = it },
                            label = { Text(strings.coworkerNameLabel) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = coworkerBadge,
                            onValueChange = { coworkerBadge = it },
                            label = { Text(strings.coworkerBadgeLabel) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = startTime,
                                onValueChange = { startTime = it },
                                label = { Text(strings.startTimeLabel) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = endTime,
                                onValueChange = { endTime = it },
                                label = { Text(strings.endTimeLabel) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    EntryType.LEAVE -> {
                        Text(strings.leaveTypeLabel, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            LeaveType.entries.forEach { lt ->
                                val ltLabel = when (language) {
                                    AppLanguage.MARATHI -> lt.labelMr
                                    AppLanguage.HINDI -> lt.labelHi
                                    AppLanguage.ENGLISH -> lt.labelEn
                                }
                                FilterChip(
                                    selected = leaveType == lt,
                                    onClick = { leaveType = lt },
                                    label = { Text(ltLabel, fontSize = 11.5.sp) }
                                )
                            }
                        }
                        OutlinedTextField(
                            value = leaveReason,
                            onValueChange = { leaveReason = it },
                            label = { Text(strings.leaveReasonLabel) },
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    EntryType.PH -> {
                        if (validPhCredits.isEmpty()) {
                            Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(8.dp)) {
                                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                    Spacer(Modifier.width(6.dp))
                                    Text(strings.noValidPhCreditMsg, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        } else {
                            Text(strings.selectPhCreditLabel, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            validPhCredits.forEach { credit ->
                                FilterChip(
                                    selected = selectedCreditId == credit.id,
                                    onClick = { selectedCreditId = credit.id },
                                    label = {
                                        Text("${credit.sourceTitle} (${credit.sourceDate} -> ${credit.expiresAtDate})")
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    EntryType.C_OFF -> {
                        if (validCOffCredits.isEmpty()) {
                            Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(8.dp)) {
                                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                    Spacer(Modifier.width(6.dp))
                                    Text(strings.noValidCOffCreditMsg, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        } else {
                            Text(strings.selectCOffCreditLabel, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            validCOffCredits.forEach { credit ->
                                FilterChip(
                                    selected = selectedCreditId == credit.id,
                                    onClick = { selectedCreditId = credit.id },
                                    label = {
                                        Text("${credit.sourceTitle} (${credit.sourceDate})")
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                if (existingEntry != null) {
                    OutlinedButton(
                        onClick = { onDelete(existingEntry) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.width(6.dp))
                        Text(strings.deleteEntryBtn, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = canSave,
                onClick = {
                    val chosenCredit = (validPhCredits + validCOffCredits).firstOrNull { it.id == selectedCreditId }
                    val newEntry = DiaryEntry(
                        userId = currentUserId,
                        dateIso = dateIso,
                        entryType = selectedType.name,
                        dutyNumber = if (selectedType == EntryType.DUTY) dutyNumber.trim() else "",
                        dutyName = if (selectedType == EntryType.DUTY) dutyName.trim() else "",
                        busNumber = if (selectedType == EntryType.DUTY) busNumber.trim() else "",
                        coworkerName = if (selectedType == EntryType.DUTY) coworkerName.trim() else "",
                        coworkerBadge = if (selectedType == EntryType.DUTY) coworkerBadge.trim() else "",
                        startTime = if (selectedType == EntryType.DUTY) startTime.trim() else "",
                        endTime = if (selectedType == EntryType.DUTY) endTime.trim() else "",
                        performedRole = if (selectedType == EntryType.DUTY && isDriverCumConductor) performedRole.name else "",
                        leaveType = if (selectedType == EntryType.LEAVE) leaveType.name else "",
                        leaveReason = if (selectedType == EntryType.LEAVE) leaveReason.trim() else "",
                        creditId = if (selectedType == EntryType.PH || selectedType == EntryType.C_OFF) selectedCreditId else "",
                        creditSourceDate = chosenCredit?.sourceDate ?: ""
                    )
                    onSave(newEntry, existingEntry)
                },
                modifier = Modifier.testTag("save_diary_entry_button")
            ) {
                Text(strings.saveEntryBtn)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}
