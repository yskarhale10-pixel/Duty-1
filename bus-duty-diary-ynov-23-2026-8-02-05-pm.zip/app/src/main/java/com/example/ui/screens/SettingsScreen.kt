package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.MainActivity
import com.example.data.PreferencesManager
import com.example.localization.AppStrings
import com.example.model.AppFontChoice
import com.example.model.AppLanguage
import com.example.model.AppThemeStyle
import com.example.model.FontSizeScale
import com.example.model.UserPreferencesState
import com.example.util.AppShareHelper
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    strings: AppStrings,
    preferences: UserPreferencesState,
    preferencesManager: PreferencesManager,
    isSyncing: Boolean,
    onSyncClick: () -> Unit,
    onLogFeedback: (String, String) -> Unit,
    onLogoutClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var feedbackText by remember { mutableStateOf("") }

    val saveApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive"),
        onResult = { uri ->
            if (uri != null) {
                val ok = AppShareHelper.copyInstalledApkToUri(context, uri)
                Toast.makeText(
                    context,
                    if (ok) "BusDutyDiary.apk saved!" else "APK export failed",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = strings.settingsHeading,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        // a. Language (Marathi / Hindi / English)
        SettingsCard(icon = Icons.Filled.Language, title = strings.languageLabel) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppLanguage.entries.forEach { lang ->
                    FilterChip(
                        selected = preferences.language == lang,
                        onClick = { scope.launch { preferencesManager.setLanguage(lang) } },
                        label = { Text(lang.nativeLabel, fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("lang_chip_${lang.code}")
                    )
                }
            }
        }

        // b. Font Family & Font Size (Small / Medium / Large / Extra Large)
        SettingsCard(icon = Icons.Filled.FontDownload, title = strings.fontFamilyLabel) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                AppFontChoice.entries.forEach { font ->
                    FilterChip(
                        selected = preferences.fontChoice == font,
                        onClick = { scope.launch { preferencesManager.setFontChoice(font) } },
                        label = { Text(font.label) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(text = strings.fontSizeLabel, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FontSizeScale.entries.forEach { scale ->
                    val label = when (preferences.language) {
                        AppLanguage.MARATHI -> scale.labelMr
                        AppLanguage.HINDI -> scale.labelHi
                        AppLanguage.ENGLISH -> scale.labelEn
                    }
                    FilterChip(
                        selected = preferences.fontSizeScale == scale,
                        onClick = { scope.launch { preferencesManager.setFontSizeScale(scale) } },
                        label = { Text(label) }
                    )
                }
            }
        }

        // c. Theme Change & Dark Mode
        SettingsCard(icon = Icons.Filled.Palette, title = strings.themeLabel) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                AppThemeStyle.entries.forEach { style ->
                    val label = when (preferences.language) {
                        AppLanguage.MARATHI -> style.labelMr
                        AppLanguage.HINDI -> style.labelHi
                        AppLanguage.ENGLISH -> style.labelEn
                    }
                    FilterChip(
                        selected = preferences.themeStyle == style,
                        onClick = { scope.launch { preferencesManager.setThemeStyle(style) } },
                        label = { Text(label) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.DarkMode, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(strings.darkModeLabel, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                }
                Switch(
                    checked = preferences.darkMode,
                    onCheckedChange = { enabled -> scope.launch { preferencesManager.setDarkMode(enabled) } }
                )
            }
        }

        // d. Data Synchronise & e. App Restart & f. Login / Logout
        Card(
            shape = MaterialTheme.shapes.medium,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onSyncClick,
                    enabled = !isSyncing,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sync_data_button")
                ) {
                    if (isSyncing) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                    } else {
                        Icon(Icons.Filled.Sync, contentDescription = null)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(strings.syncDataBtn, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        val intent = Intent(context, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        }
                        context.startActivity(intent)
                        (context as? Activity)?.finish()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("restart_app_button")
                ) {
                    Icon(Icons.Filled.RestartAlt, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.restartAppBtn)
                }

                Button(
                    onClick = onLogoutClick,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_logout_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("${strings.logoutBtn} (${Firebase.auth.currentUser?.email ?: ""})", maxLines = 1)
                }
            }
        }

        // g. User Feedback SMS Box
        SettingsCard(icon = Icons.Filled.Sms, title = strings.feedbackBoxTitle) {
            OutlinedTextField(
                value = feedbackText,
                onValueChange = { feedbackText = it },
                placeholder = { Text(strings.feedbackHint) },
                minLines = 3,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("feedback_sms_input")
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    val msg = feedbackText.trim()
                    if (msg.isNotBlank()) {
                        onLogFeedback(msg, "SMS")
                        AppShareHelper.sendSms(context, phone = "8208748351", body = msg)
                        feedbackText = ""
                    }
                },
                enabled = feedbackText.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("send_feedback_sms_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(strings.sendSmsFeedbackBtn, fontWeight = FontWeight.Bold)
            }
        }

        // h. Contact WhatsApp & i. Email ID
        SettingsCard(icon = Icons.AutoMirrored.Filled.Chat, title = strings.contactSupportTitle) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(
                    onClick = { AppShareHelper.openWhatsApp(context, "918208748351", "Namaskar! Bus Duty Diary App Support") },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(strings.whatsappSupportBtn, style = MaterialTheme.typography.labelSmall)
                }
                FilledTonalButton(
                    onClick = { AppShareHelper.openEmail(context, "yskarhale10@gmail.com") },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Email, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(strings.emailSupportBtn, style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        // APK Download & Share Section
        SettingsCard(icon = Icons.Filled.Android, title = strings.apkSectionTitle) {
            Button(
                onClick = { saveApkLauncher.launch("BusDutyDiary.apk") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("download_apk_button")
            ) {
                Icon(Icons.Filled.Download, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(strings.downloadApkBtn, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(
                onClick = { AppShareHelper.shareInstalledApk(context) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("share_apk_button")
            ) {
                Icon(Icons.Filled.Share, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(strings.shareApkBtn, fontWeight = FontWeight.Bold)
            }
        }

        // Locked Creator Attribution & App Integrity Protection Card
        Surface(
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = strings.creatorLockTitle,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Text(
                    text = strings.creatorLockBody,
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Powered by & Created by: YADAV KARHALE",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "WhatsApp / Mob: 8208748351  |  Email: yskarhale10@gmail.com",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun SettingsCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}
