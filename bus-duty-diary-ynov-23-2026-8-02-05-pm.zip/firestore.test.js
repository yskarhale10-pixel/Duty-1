const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_101";
const BOB_UID = "bob_uid_202";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write any user collection", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).collection("diary_entries").get());
  await assertFails(
    unauth.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      name: "Unauth",
      designation: "DRIVER",
      weeklyOffDay: 7,
      profileSubmitted: false,
      createdAt: new Date(Date.now() - 1000),
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Owner can create and partially update EmployeeProfile; cross-user & shadow keys denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = new Date(Date.now() - 5000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      name: "Ramesh Patil",
      email: "ramesh@example.com",
      mobile: "9876543210",
      dateOfBirth: "1990-05-12",
      designation: "DRIVER_CUM_CONDUCTOR",
      weeklyOffDay: 7,
      profileSubmitted: true,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      name: "Ramesh S Patil",
      weeklyOffDay: 3,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Cross-user read/write rejected
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).update({ name: "Hijack", updatedAt: new Date(Date.now() - 1000) }));

  // Immutable createdAt mutation rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Shadow/ghost field rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isAdmin: true,
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Owner can create, list, and update DiaryEntry; future timestamps and @DocumentId id field rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = new Date(Date.now() - 5000);

  // Create DUTY entry keyed by yyyy-MM-dd
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("diary_entries").doc("2026-11-23").set({
      userId: ALICE_UID,
      dateIso: "2026-11-23",
      entryType: "DUTY",
      dutyNumber: "D-104",
      dutyName: "Pune - Swargate Express",
      busNumber: "MH-12-ST-4410",
      coworkerName: "Suresh Shinde",
      coworkerBadge: "B-452",
      startTime: "06:00 AM",
      endTime: "02:30 PM",
      performedRole: "DRIVER",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // List subcollection succeeds for owner
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("diary_entries").get()
  );

  // Cross-user list fails
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("diary_entries").get()
  );

  // Partial update to LEAVE succeeds
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("diary_entries").doc("2026-11-23").update({
      entryType: "LEAVE",
      leaveType: "CL",
      leaveReason: "Family event",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Including @DocumentId `id` field in payload fails
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("diary_entries").doc("2026-11-24").set({
      id: "2026-11-24",
      userId: ALICE_UID,
      dateIso: "2026-11-24",
      entryType: "DUTY",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Future timestamp rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("diary_entries").doc("2026-11-25").set({
      userId: ALICE_UID,
      dateIso: "2026-11-25",
      entryType: "DUTY",
      createdAt: new Date(Date.now() + 60000),
      updatedAt: new Date(Date.now() + 60000),
    })
  );
});

test("Owner can create, list, and redeem LeaveCredit; cross-user denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = new Date(Date.now() - 5000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("leave_credits").doc("ph_2026-11-08").set({
      userId: ALICE_UID,
      creditType: "PH",
      sourceDate: "2026-11-08",
      sourceTitle: "Diwali Laxmi Pujan",
      expiresAtDate: "2027-02-08",
      redeemed: false,
      redeemedOnDate: "",
      sourceKind: "DEPOSITED",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("leave_credits").get()
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("leave_credits").doc("ph_2026-11-08").update({
      redeemed: true,
      redeemedOnDate: "2026-11-23",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("leave_credits").get()
  );
});

test("Owner can create UserFeedback and cannot update it", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const ts = new Date(Date.now() - 2000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("feedback").doc("fb_1").set({
      userId: ALICE_UID,
      message: "Great app for drivers!",
      channel: "WHATSAPP",
      createdAt: ts,
    })
  );

  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("feedback").doc("fb_1").update({
      message: "Edited",
    })
  );
});
